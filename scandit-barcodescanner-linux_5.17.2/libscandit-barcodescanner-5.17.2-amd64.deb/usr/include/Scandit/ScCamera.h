/**
 * \file ScCamera.h
 * \brief Camera creation and control interface.
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_CAMERA_H_
#define SC_CAMERA_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScCommon.h>
#include <Scandit/ScImageDescription.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \struct ScCamera
 *
 * \brief Opaque handle to a camera object.
 *
 * Currently this camera interface is only available on Linux platforms with Video4Linux2 (v4l2)
 * camera drivers. On other platforms, a dummy object is returned that does not do anything. On
 * mobile platforms like Andoid and iOS the platform's native camera interface should be used.
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueCamera ScCamera;
//! \}

/**
 * \brief A unsigned step-wise description of a size.
 *
 * Describes the resolution capabilities of a camera in step-wise mode. The camera supports all
 * resolutions in the range of min_width to max_width and min_heigth to max_height  in steps of
 * step_width and step_height.
 *
 * \see ScCameraMode for further information about resolution modes.
 *
 * \since 4.7.0
 */
typedef struct {
    uint32_t min_width; //!< minimum x dimension
    uint32_t max_width; //!< maximum x dimension
    uint32_t step_width; //!< x dimension step size
    uint32_t min_height; //!< minimum y dimension
    uint32_t max_height; //!< maximum y dimension
    uint32_t step_height; //!< y dimension step size
} ScStepwiseResolution;

/**
 * \brief Describes a framerate.
 *
 * \note The framerate are described as fractions with a numerator and a denominator
 *
 * \since 4.7.0
 */
typedef struct {
    uint32_t numerator; //!< numerator of the frameraet
    uint32_t denominator; //!< denominator of the framerate
} ScFramerate;

/**
 * \brief Returns the time between two frames in seconds.
 *
 * \param frame_rate a valid frame rate object. Must not be null
 * \returns Returns the frame interval time of a framerate object (in seconds)
 *
 * \since 4.7.0
 */
SC_EXPORT float sc_framerate_get_frame_interval(const ScFramerate *frame_rate);

/**
 * \brief Returns the number of frames per second.
 *
 * \param frame_rate a valid frame rate object. Must not be null
 * \returns Returns the frame per second rate of a framerate object
 *
 * \since 4.7.0
 */
SC_EXPORT float sc_framerate_get_fps(const ScFramerate *frame_rate);

/**
 * \brief A step-wise description of a framerate.
 *
 * Describes the framerate capabilities of a camera in step-wise mode (for a specific resolution).
 * The camera supports all framerates in the range of min to max in steps of step.
 *
 * \see ScCameraMode for further information about framerate modes.
 *
 * \since 4.7.0
 */
typedef struct {
    ScFramerate min;
    ScFramerate max;
    ScFramerate step;
} ScStepwiseFramerate;

/**
 * \brief Describes the resolution mode of the camera
 *
 * This enum defines the return values of sc_camera_get_resolution_mode() and sc_camera_get_framerate_mode().
 * It can therefore describe both properties of the camera in an analog way.
 *
 * The resolution mode of the camera may be \ref SC_CAMERA_MODE_DISCRETE or
 * \ref SC_CAMERA_MODE_STEPWISE. In discrete mode the camera supports a predefined set of
 * resolutions. The possible resolutions can be queried with sc_camera_query_supported_resolutions().
 * In step-wise mode the camera supports resolution between a minimum and maximum value in stepwise
 * increments. More precisely, all resolutions in the range of \c min_width to \c max_width and
 * \c min_height to \c max_height in steps of \c step_width and \c step_height are supported. The
 * minimum, maximum and step values can be queried by sc_camera_query_supported_resolutions_stepwise().
 *
 * The framerate mode of the camera may be \ref SC_CAMERA_MODE_DISCRETE or
 * \ref SC_CAMERA_MODE_STEPWISE. In discrete mode the camera supports a predefines set of framerates
 * at which it can capture video. The possible framerate can be queried with
 * sc_camera_query_supported_framerates(). In step-wise mode the camera supports framerates between
 * a minimum an maximum value in stepwise increments. More precisely, all resolutions in the range of
 * \c min to \c max in steps of \p step are supported. Note that framerates are represented using a
 * fraction. The minimum, maximum and step values can be queried by
 * sc_camera_query_supported_framerates_stepwise().
 *
 * \since 4.7.0
 */
typedef enum {
    SC_CAMERA_MODE_UNKNOWN   = 0, //!< the camera resolution mode is not known
    SC_CAMERA_MODE_DISCRETE  = 1, //!< the camera captures at a finite set of discrete resolutions
    SC_CAMERA_MODE_STEPWISE  = 2  //!< the camera captures at a wide range of step-wise generated resolutions
} ScCameraMode;

/**
 * \brief Create a camera object using default values.
 *
 * \return a newly allocated camera or null on error
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScCamera * sc_camera_new(void);

/**
 * \brief Create a camera object with the requested number of frame buffers.
 *
 * \param buffer_count number of buffers used by the camera, e.g. 4
 * \return a newly allocated camera or null on error
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScCamera * sc_camera_new_with_buffer_count(uint32_t buffer_count);

/**
 * \brief Create a camera object from a device path.
 *
 * Setting too many frame buffers can make the allocation fail.
 *
 * \param device_path path to the camera device, e.g. /dev/video0
 * \param buffer_count number of frame buffers to use, e.g. 4
 * \return a newly allocated camera or null on error
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScCamera * sc_camera_new_from_path(const char *device_path, uint32_t buffer_count);

/**
 * \brief Decrease reference count of camera by one.
 *
 * When the reference count drops to zero, the camera is deallocated.
 *
 * \param camera A valid camera object. May be null
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT void sc_camera_release(ScCamera *camera);

/**
 * \brief Increase reference count of camera by one.
 *
 * \param camera A valid camera object. Must not be null
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT void sc_camera_retain(ScCamera *camera);

/**
 * \brief Returns the resolution of the camera in pixel (width, height).
 *
 * \param camera A valid camera object. Must not be null
 * \returns The resolution settings of the camera
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScSize
sc_camera_get_resolution(const ScCamera *camera);

/**
 * \param camera A valid camera object. Must not be null.
 * \returns the layout used by the camera
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScImageLayout
sc_camera_get_image_layout(const ScCamera *camera);

/**
 * \brief Query the resolution mode of the camera.
 *
 * This function returns the supported resolution mode of this camera. Depending on the
 * resolution mode, either sc_camera_query_supported_resolutions(), or
 * sc_camera_query_supported_resolutions_stepwise() must be used to query available
 * resolutions. See \ref ScCameraMode for a description of possible return
 * values.
 *
 * \param camera A valid camera object. Must not be null.
 * \returns the resolution mode used by the camera.
 * \see ScCameraMode for an explanation of the different resolution modes.
 *
 * \since 4.7.0
 * \memberof ScCamera
 */
SC_EXPORT ScCameraMode
sc_camera_get_resolution_mode(const ScCamera *camera);

/**
 * \brief Query the framerate mode of the camera.
 *
 * This function returns the supported framerate mode of this camera. Depending on the
 * framerate mode, either sc_camera_query_supported_framerates(), or
 * sc_camera_query_supported_framerates_stepwise() must be used to query available
 * framerates. See \ref ScCameraMode for a description of possible return
 * values.
 *
 * \param camera A valid camera object. Must not be null.
 * \returns the resolution mode used by the camera.
 * \see ScCameraMode for an explanation of the different resolution modes.
 *
 * \since 4.7.0
 * \memberof ScCamera
 */
SC_EXPORT ScCameraMode
sc_camera_get_framerate_mode(const ScCamera *camera);

/**
 * \brief Query supported discrete resolutions of the camera.
 *
 * Use this function on camera objects whose resolution mode is
 * \ref SC_CAMERA_MODE_DISCRETE. For camera objects with
 * \ref SC_CAMERA_MODE_STEPWISE, use sc_camera_query_supported_resolutions_stepwise().
 *
 * \param camera A valid camera object. Must not be null.
 * \param resolution_array Pre-allocated array of resolution objects into which the resolutions
 *      are written.
 * \param resolution_array_length Number of objects in the pre-allocated resolution array.
 * \returns The number of resolution objects that were written to the resolution array. 0 is
 *      returned if the camera resolution mode is not \ref SC_CAMERA_MODE_DISCRETE.
 * \see ScCameraMode for the difference between discrete and step-wise resolution mode
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT int32_t
sc_camera_query_supported_resolutions(const ScCamera *camera, ScSize *resolution_array,
                                      uint32_t resolution_array_length);

/**
 * \brief Query supported step-wise resolutions of the camera.
 *
 * \param camera A valid camera object. Must not be null.
 * \param resolutions pointer to a ScStepwiseResolution struct in which the result will be written
 * \returns true on success and false if the camera resolution mode is not
 *      \ref SC_CAMERA_MODE_STEPWISE.
 * \see ScCameraMode for the difference between discrete and step-wise resolution mode.
 *
 * \since 4.7.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool
sc_camera_query_supported_resolutions_stepwise(const ScCamera *camera,
                                      ScStepwiseResolution *resolutions);

/**
 * \brief Query supported discrete framerates of the camera at a given resolution
 *
 * Use this function on camera objects whose resolution mode is
 * \ref SC_CAMERA_MODE_DISCRETE. For camera objects with
 * \ref SC_CAMERA_MODE_STEPWISE, use sc_camera_query_supported_framerates_stepwise()
 *
 * \param camera A valid camera object. Must not be null.
 * \param resolution The resolution at which we want to know the the supported framerates.
 * \param framerate_array Pre-allocated array of framerate objects into which the framerates are
 *      written.
 * \param framerate_array_length Number of objects in the pre-allocated resolution array.
 * \returns The n umber of framrate objects that were written in the framerate array. 0 is returned if the camera framerate mode is not \ref SC_CAMERA_MODE_DISCRETE
 * \see ScCameraMode for the differences between discrete and step-wise framerate mode
 *
 * \since 4.7.0
 * \memberof ScCamera
 */
SC_EXPORT int32_t
sc_camera_query_supported_framerates(const ScCamera *camera, ScSize resolution,
                                      ScFramerate *framerate_array,
                                      uint32_t framerate_array_length);

/**
 * \brief Query supported step-wise framerates of the camera at a given resolution
 *
 * \param camera A valid camera object. Must not be null.
 * \param resolution The resolution at which we want to know the supported framerates.
 * \param framerates Pointer to a ScStepwiseFramerate struct in which the result will be written
 * \returns true on success and false if the camera resolution mode is not
 *      \ref SC_CAMERA_MODE_STEPWISE
 *
 * \since 4.7.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool
sc_camera_query_supported_framerates_stepwise(const ScCamera *camera, ScSize resolution,
                                      ScStepwiseFramerate *framerates);

/**
 * \brief Tries to set the camera resolution.
 *
 * \param camera A valid camera object. Must not be null
 * \param resolution A resolution object. Must not be null
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool
sc_camera_request_resolution(ScCamera *camera, ScSize resolution);

/**
 * \brief Tries to set the camera framerate.
 *
 * \param camera A valid camera object. Must not be null
 * \param framerate A framerate object. Must not be null
 * \returns true on success and false on failure
 *
 * \since 5.15.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_request_framerate(ScCamera *camera, ScFramerate framerate);

/**
 * \brief Tries to set the autofocus mode of the camera.
 *
 * \param camera A valid camera object. Must not be null
 * \param mode desired focus mode
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_set_focus_mode(ScCamera *camera, ScCameraFocusMode mode);

/**
 * \brief Sets the autofocus distance manually. Only possible when the autofocusmode is OFF.
 *
 * \param camera A valid camera object. Must not be null
 * \param distance device specific focus distance value
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_set_manual_auto_focus_distance(ScCamera *camera, int32_t distance);

/**
 * \param camera A valid camera object. Must not be null
 * \param image_description image description of the returned frame data. Can be null to ignore the output.
 * \returns the latest frame data that the camera captured or null on error.
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT const uint8_t * sc_camera_get_frame(ScCamera *camera, ScImageDescription * image_description);

/**
 * \brief Tells the camera to start capturing images.
 *
 * \param camera A valid camera object. Must not be null
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_start_stream(ScCamera *camera);

/**
 * \brief Tells the camera to stop capturing images.
 *
 * \param camera A valid camera object. Must not be null
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_stop_stream(ScCamera *camera);

/**
 * \brief Requeues the buffer after the data has been used.
 *
 * \param camera A valid camera object. Must not be null
 * \param frame_data Image data pointer from this camera.  Must not be null
 * \returns true on success and false on failure
 *
 * \since 4.6.0
 * \memberof ScCamera
 */
SC_EXPORT ScBool sc_camera_enqueue_frame_data(ScCamera *camera, const uint8_t *frame_data);


#if defined(__cplusplus)
}
#endif


#endif // SC_CAMERA_H_


