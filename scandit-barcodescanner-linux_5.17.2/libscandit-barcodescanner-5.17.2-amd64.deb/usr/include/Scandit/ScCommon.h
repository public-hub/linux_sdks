/**
 * \file ScCommon.h
 *
 * \brief Common functions and data structures.
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_COMMON_H_
#define SC_COMMON_H_


#include <Scandit/ScConfig.h>
#include <Scandit/ScImageDescription.h>

#if defined(__cplusplus)
extern "C" {
#endif


/**
 * \brief A 2-dimensional point with integer precision.
 *
 * \since 4.6.0
 */
typedef struct {
    /**
     * \brief X-coordinate
     */
    int32_t x;
    /**
     * \brief Y-coordinate
     */
    int32_t y;
} ScPoint;


/**
 * \brief Helper function to initialize a point with x, y coordinates.
 *
 * \param x The x-coordinate.
 * \param y The y-coordinate.
 *
 * \returns The created point.
 *
 * \memberof ScPoint
 *
 * \since 4.6.0
 */
inline ScPoint sc_point_make(int x, int y) {
    ScPoint point;
    point.x = x;
    point.y = y;
    return point;
}


/**
 * \brief A 2-dimensional polygon with 4 corners.
 *
 * \since 4.6.0
 */
typedef struct  {
    /**
     * \brief Top left corner of the quadrilateral.
     */
    ScPoint top_left;
    /**
     * \brief Top right corner of the quadrilateral.
     */
    ScPoint top_right;
    /**
     * \brief Bottom right corner of the quadrilateral.
     */
    ScPoint bottom_right;
    /**
     * \brief Bottom left corner of the quadrilateral.
     */
    ScPoint bottom_left;
} ScQuadrilateral;


/**
 * \brief Helper function to initialize a quadrilateral with 4 corners.
 *
 * \param tl Top-left corner.
 * \param tr Top-right corner.
 * \param br Bottom-right corner.
 * \param bl Bottom-left corner.
 * \returns The created quadrilateral.
 *
 * \memberof ScQuadrilateral
 */
SC_EXPORT ScQuadrilateral
sc_quadrilateral_make(ScPoint tl, ScPoint tr, ScPoint br, ScPoint bl);

/**
 * \brief A 2-dimensional point with floating point precision.
 *
 * \since 4.6.0
 */
typedef struct {
    /**
     * \brief X-coordinate
     */
    float x;
    /**
     * \brief Y-coordinate
     */
    float y;
} ScPointF;

/**
 * \brief Helper function to initialize a point with x, y coordinates.
 *
 * \param x The x-coordinate.
 * \param y The y-coordinate.
 *
 * \returns The created point.
 *
 * \memberof ScPointF
 *
 * \since 4.7.0
 */
inline ScPointF sc_point_f_make(float x, float y) {
    ScPointF point;
    point.x = x;
    point.y = y;
    return point;
}

/**
 * \brief A 2-dimensional unsigned size.
 *
 * \since 4.6.0
 */
typedef struct {
    uint32_t width;  //!< x dimension
    uint32_t height; //!< y dimension
} ScSize;

/**
 * \brief A 2-dimensional size with floating point precision.
 *
 * \since 4.6.0
 */
typedef struct {
    float width;  //!< x dimension
    float height; //!< y dimension
} ScSizeF;

/**
 * \brief A 2-dimensional rectangle with floating point precision.
 *
 * The rectangle is defined by the coordinates of the upper-left corner together
 * with width and height. Width and height must always be larger or equal than
 * zero.
 *
 * \since 4.6.0
 */
typedef struct  {
    /**
     * \brief Upper-left corner of the rectangle.
     */
    ScPointF position;
    /**
     * \brief Width and height of the rectangle. Both must larger or equal than zero.
     */
    ScSizeF size;
} ScRectangleF;

/**
 * \brief Helper function to initialize a rectangle.
 *
 * \param position_x The x-coordinate of the top-left corner of the rectangle.
 * \param position_y The y-coordinate of the top-left corner of the rectangle.
 * \param width The width of the rectangle. Must not be negative.
 * \param height The height of the rectangle. Must not be negative.
 * \returns The created rectangle.
 *
 * \since 4.6.0
 * \memberof ScRectangleF
 */
SC_EXPORT ScRectangleF
sc_rectangle_f_make(float position_x, float position_y, float width, float height);

/**
 * \brief Calculates and returns the center of the rectangle.
 *
 * \param rectangle The rectangle to calculate the center of
 * \returns The calculated center.
 *
 * \since 4.7.0
 * \memberof ScRectangleF
 */
SC_EXPORT ScPointF
sc_rectangle_f_get_center(ScRectangleF rectangle);

/**
 * \brief Describes the focus mode of a camera.
 *
 * \since 4.6.0
 */
typedef enum  {
    SC_CAMERA_FOCUS_MODE_UNKNOWN  = 0, //!< the focus capabilities are not known
    SC_CAMERA_FOCUS_MODE_FIXED    = 1, //!< the camera cannot change its focus
    SC_CAMERA_FOCUS_MODE_AUTO     = 2, //!< the camera automatically adjusts the focus to create a sharp image
    SC_CAMERA_FOCUS_MODE_MANUAL   = 4  //!< the camera is controlled by the user
} ScCameraFocusMode;

/**
 * \brief Deallocates the memory allocation pointed to by \p pointer
 *
 * \param pointer The pointer to be deallocated. In case \p pointer is a null pointer, no operation
 * is performed.
 */
SC_EXPORT void sc_free(void *pointer);

/**
 * \brief Structure for holding error information
 *
 * \since 4.11.0
 */
typedef struct {
    /**
     * \brief error message. Set to NULL in case there is no error
     */
    const char       *message;

    /**
     * \brief error code, 0 if there is no error, a positive value otherwise.
     */
    uint32_t       code;
} ScError;

/**
 * \brief Enumeration of different error types
 *
 * \since 5.8
 */
typedef enum {
    SC_NO_ERROR                 = 0,
    SC_ERROR_UNKNOWN            = 1,
    SC_ERROR_NOT_IMPLEMENTED    = 2,
    SC_ERROR_INVALID_INPUT      = 3,
    SC_ERROR_INTERNAL_ERROR     = 4
} ScErrorType;


/**
 * \brief free's any memory associated with the error
 *
 * Upon exit, the data fields are set to 0.
 *
 * \param error the error to free.
 *
 * \since 4.11.0
 */
SC_EXPORT void sc_error_free(ScError *error);


/**
 * \brief Enumeration of different information strings
 *
 * Values of this enumeration are passed to \ref sc_get_information_string to retrieve
 * specific information.
 *
 * \since 4.16.1
 */
typedef enum {
    SC_INFORMATION_KEY_SOFTWARE_LICENSES = 0,
    SC_INFORMATION_KEY_SDK_VERSION = 1,
    SC_INFORMATION_KEY_SDK_BUILD = 2,
} ScInformationKey;

/**
 * \brief Get information string
 *
 * \param key information identifier
 * \return The string associated with the given key, null if no string is associated
 *     with the key. The returned key is constant and must not be freed by the caller.
 *
 * \since 4.16.1
 */
SC_EXPORT const char* sc_get_information_string(ScInformationKey key);

/**
 * \brief A 2-dimensional bitmap/image
 *
 * \since 5.8
 */
typedef struct {
    ScImageDescription* description;
    uint8_t* data;
} ScImageBuffer;

/**
 * \brief Frees the data contained in the image
 *
 * Effectively calls sc_image_description_release on the description and frees the memory contained
 * in data. When passed a NULL pointer, this call has no effect.
 *
 * \param image Image to free. Can be null.
 *
 * \since 5.8
 */
SC_EXPORT void
sc_image_buffer_free(ScImageBuffer* image);


#if defined(__cplusplus)
}
#endif

#endif // SC_COMMON_H_
