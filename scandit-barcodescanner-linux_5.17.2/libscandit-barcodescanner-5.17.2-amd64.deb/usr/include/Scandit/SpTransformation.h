//------------------------------------------------------------------------------------------------//
//                        This file is part of the Scandit Parsing Library                        //
//                                                                                                //
//                   Copyright (c) 2016-2017 Scandit AG. All rights reserved                      //
//------------------------------------------------------------------------------------------------//

#ifndef SCANDIT_PARSER_TRANSFORMATION_H
#define SCANDIT_PARSER_TRANSFORMATION_H

#include <Scandit/ScRecognitionContext.h>

#include <Scandit/Parser/SpCommon.h>
#include <Scandit/Parser/Private/SpTransformationData.h>

SP_BEGIN_EXTERN_C

typedef struct SpOpaqueTransformation SpTransformation;

/**
 * Creates a transformation if the license used by the context permits it.
 *
 * \param context a recognition context. Must not be null.
 * \param type type of the parser
 * \param status indicates errors during instantiation. Check this flag if the returned parser
 *               is a null pointer. Also, see \ref sc_context_status_flag_get_message and
 *               \ref ScContextStatusFlag for more information about status flags.
 * \return a transformation object or null if the license does not include the parser
 */
SP_EXPORT SpTransformation *
sp_transformation_new_with_context(ScRecognitionContext *context, ScContextStatusFlag *status);

/**
 * Creates a transformation object
 *
 * \returns a transformation
 */
SP_EXPORT SpTransformation * sp_transformation_new(void);

/**
 * \brief Free the transformation and associated resources
 *
 * \param transformation The transformation to free. May be null
 */
SP_EXPORT void sp_transformation_free(SpTransformation *transformation);

/**
 * \brief transform the data contained in the given string
 *
 * \return True on success, false if the data could not be parsed for some
 *      reason. In case of error, more details on why the parsing failed can be
 *      obtained by calling \ref sp_parse_result_get_error_message.
 */
SP_EXPORT SpBool
sp_transformation_transform_data(SpTransformation *transformation, SpTransformationData *inputs[],
                                 size_t inputs_length, SpTransformationData **result);

/**
 * \brief Reads the transformation type and properties from the given json string
 *
 * \return the error message. If there were no errors, a NULL string is returned.
 *      The life-time of the string is not bound to the life-time of the transformation
 *      object. The user has to free the SpData structure using sp_data_free.
 */
SP_EXPORT SpData
sp_transformation_from_json(SpTransformation *transformation, const char *json_str, size_t length);

SP_END_EXTERN_C

#endif // SCANDIT_PARSER_TRANSFORMATION_H
