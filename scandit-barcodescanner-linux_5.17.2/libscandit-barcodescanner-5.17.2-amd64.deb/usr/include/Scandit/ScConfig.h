/**
 * \file ScConfig.h
 * \brief Common definitions used throughout the ScanditSDK API.
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_CONFIG_H_
#define SC_CONFIG_H_

//! \cond SuppressDoxygen
#if !defined(SC_EXTERN)
/**
 * \brief Use this for defining external symbols
 */
#define SC_EXTERN extern
#endif

#if defined(_WIN32)
#   if defined(SC_STATIC_LIBRARY) && SC_STATIC_LIBRARY==1
#		define SC_EXPORT
# 	else
#		if defined(SC_BUILD_SCANDIT_SDK)
#	  		define SC_EXPORT __declspec(dllexport)
#		else
#			define SC_EXPORT __declspec(dllimport)
#		endif
#	endif
#elif defined(SC_GENERATE_DOCS)
#	define SC_EXPORT
#elif !defined(SWIG)
#	define SC_EXPORT __attribute__((visibility("default")))
#endif

#if !defined(SC_PLATFORM_ANDROID)
#	if defined(__ANDROID__) && __ANDROID__
#		define SC_PLATFORM_ANDROID 1
#	else
#		define SC_PLATFORM_ANDROID 0
#	endif
#endif

#if !defined(SC_PLATFORM_IOS)
#   if defined(__APPLE__)
#       include "TargetConditionals.h"
#       if TARGET_IPHONE_SIMULATOR || TARGET_OS_IPHONE
#	    	define SC_PLATFORM_IOS 1
#	    else
#	    	define SC_PLATFORM_IOS 0
#	    endif
#   else
#       define SC_PLATFORM_IOS 0
#   endif
#endif

#if !defined(SC_PLATFORM_GENERIC)
#	if SC_PLATFORM_ANDROID || SC_PLATFORM_IOS
#		define SC_PLATFORM_GENERIC 0
#	else
#		define SC_PLATFORM_GENERIC 1
#	endif
#endif
//! \endcond

/**
 * \brief Major Version of the Scandit SDK
 * \returns Integer representing the major version
 */
#define SC_VERSION_MAJOR 5

/**
 * \brief Minor Version of the Scandit SDK
 * \returns Integer representing the minor version
 */
#define SC_VERSION_MINOR 17

/**
 * \brief Patch Version of the Scandit SDK
 * \returns Integer representing the patch version
 */
#define SC_VERSION_PATCH 2


/**
 * \brief Version suffix, e.g. BETA1, SNAPSHOT
 * \returns Representation of the version suffix
 */
#define SC_VERSION_SUFFIX 

//! \cond SuppressDoxygen
#define SC_VERSION_MAKE(major, minor, patch) \
    ((major * 10000) + (minor * 100) + patch)
//! \endcond


/**
 * \brief ScanditSDK version encoded as an integer
 * \returns Integer representation of the SDK version
 */
#define SC_VERSION_INT SC_VERSION_MAKE(SC_VERSION_MAJOR, SC_VERSION_MINOR, SC_VERSION_PATCH)


//! \cond SuppressDoxygen
#define SC_VERSION_STRING_MAKE_(major, minor, patch, suffix) \
	#major "." #minor "." #patch #suffix

#define SC_VERSION_STRING_MAKE(major, minor, patch, suffix) \
	SC_VERSION_STRING_MAKE_(major, minor, patch, suffix)
//! \endcond

/**
 * \brief Scandit SDK version string of the form $major.$minor.$patch$suffix
 * \returns String representation of the SDK version
 */
#define SC_VERSION_STRING \
	SC_VERSION_STRING_MAKE(SC_VERSION_MAJOR, SC_VERSION_MINOR, \
	                       SC_VERSION_PATCH, SC_VERSION_SUFFIX)


#include <inttypes.h>

/**
 * \brief Boolean value, can be SC_TRUE or SC_FALSE.
 */
typedef int32_t ScBool;

/**
 * \brief True value
 * \returns Integer representing true
 */
#define SC_TRUE 1

/**
 * \brief False value
 * \returns Integer representing false
 */
#define SC_FALSE 0

#endif // SC_CONFIG_H_
