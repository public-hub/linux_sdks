//------------------------------------------------------------------------------------------------//
//                        This file is part of the Scandit Parsing Library                        //
//                                                                                                //
//                   Copyright (c) 2016-2017 Scandit AG. All rights reserved                      //
//------------------------------------------------------------------------------------------------//

#ifndef SCANDIT_PARSER_COMMON_H
#define SCANDIT_PARSER_COMMON_H

#include <stdint.h>
#include <string.h>

#include "Scandit/ScByteArray.h"

#if defined(__cplusplus)
#   define SP_BEGIN_EXTERN_C extern "C" {
#   define SP_END_EXTERN_C }
#else
#   define SP_BEGIN_EXTERN_C
#   define SP_END_EXTERN_C
#endif

SP_BEGIN_EXTERN_C

typedef int SpBool;

#define SP_TRUE 1
#define SP_FALSE 0

#if defined(_WIN32)
#   if defined(SC_STATIC_LIBRARY) && SC_STATIC_LIBRARY==1
#		define SP_EXPORT
# 	else
#		if defined(SC_BUILD_SCANDIT_SDK)
#	  		define SP_EXPORT __declspec(dllexport)
#		else
#			define SP_EXPORT __declspec(dllimport)
#		endif
#	endif
#elif defined(SC_GENERATE_DOCS)
#	define SP_EXPORT
#elif !defined(SWIG)
#	define SP_EXPORT __attribute__((visibility("default")))
#endif

/**
 * \brief Represents a binary blob of data, or a string of characters.
 */
typedef ScByteArray SpData;

/**
 * \brief Free the data
 *
 * \param data The data to free.
 *
 * \deprecated use sc_byte_array_free()
 */
SP_EXPORT void sp_data_free(SpData data);

SP_END_EXTERN_C

#endif // SCANDIT_PARSER_COMMON_H
