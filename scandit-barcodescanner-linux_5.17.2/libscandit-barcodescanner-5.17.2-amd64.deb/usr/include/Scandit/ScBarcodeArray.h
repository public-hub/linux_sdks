/**
 * \file ScBarcodeArray.h
 * \brief Functions to manage an array of barcodes
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_BARCODE_ARRAY_H_
#define SC_BARCODE_ARRAY_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScBarcode.h>
#include <Scandit/ScByteArray.h>

#if defined(__cplusplus)
extern "C" {
#endif


/**
 * \struct ScBarcodeArray
 *
 * \brief A fixed-size array of barcode objects.
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueBarcodeArray ScBarcodeArray;
//! \}

/**
 * \brief Increase reference count of barcode array by one.
 *
 * \param array The barcode array. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeArray
 */
SC_EXPORT void sc_barcode_array_retain(ScBarcodeArray *array);

/**
 * \brief Decrease reference count of barcode array by one.
 *
 * When the reference count drops to zero, the barcode array is deallocated.
 *
 * \param array the barcode array. May be null
 *
 * \since 4.6.0
 * \memberof ScBarcodeArray
 */
SC_EXPORT void sc_barcode_array_release(ScBarcodeArray *array);

/**
 * \brief Get the number of barcodes in the array.
 *
 * \returns The number of barcodes.
 *
 * \param array The barcode array. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeArray
 */
SC_EXPORT uint32_t
sc_barcode_array_get_size(const ScBarcodeArray *array);

/**
 * \brief Get barcode at specific index in array.
 *
 * \returns The barcode at the specific index. In case the index is out of bounds, a
 *    NULL barcode is returned.
 *
 * \param array the barcode array. Must not be null.
 * \param index the index of the barcode to retrieve.
 *
 * \since 4.6.0
 * \memberof ScBarcodeArray
 */
SC_EXPORT ScBarcode *
sc_barcode_array_get_item_at(const ScBarcodeArray *array, uint32_t index);



#if defined(__cplusplus)
}
#endif


#endif // SC_BARCODE_ARRAY_H_


