/**
 * \file ScEncodingArray.h
 * \brief Functions to manage an array of encoding ranges
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2016 Scandit AG. All rights reserved.
 */

#ifndef SC_ENCODING_ARRAY_H_
#define SC_ENCODING_ARRAY_H_

#include "Scandit/ScByteArray.h"
#include "Scandit/ScConfig.h"

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \brief Represents a binary blob of data, or a string of characters.
 */
typedef ScByteArray ScData;

/**
 * \brief Free the data
 *
 * \param data The data to free.
 *
 * \deprecated use sc_byte_array_free()
 */
SC_EXPORT void
sc_data_free(ScData data);

/**
 * \struct ScEncodingRange
 *
 * \brief Character encoding of a range of bytes
 *
 * \since 5.8.0
 */
//! \{
typedef struct {
    ScData encoding; //!< encapsulates a charset encoding name as defined by IANA (http://www.iana.org/assignments/character-sets/character-sets.xhtml)
    uint32_t start; //!< start index in the data
    uint32_t end; //!< index after the last element in the data
} ScEncodingRange;
//! \}

/**
 * \brief Frees the data of the encoding range
 *
 * \param encoding_range The encoding range.
 *
 * \since 5.8.0
 * \memberof ScEncodingRange
 */
SC_EXPORT void
sc_encoding_range_free(ScEncodingRange encoding_range);

/**
 * \brief Create new ScEncodingRange
 *
 * \returns The created ScEncodingRange.
 *
 * \param c_str The encoding string (e.g. ASCII)
 * \param start starting index of the encoding string in the code
 * \param end ending index of the encoding string in the code
 *
 * \since 5.8.0
 * \memberof ScEncodingRange
 */
SC_EXPORT ScEncodingRange
sc_encoding_range_new(const char* c_str, uint32_t start, uint32_t end);

/**
 * \struct ScEncodingArray
 *
 * \brief An array of encoding ranges
 *
 * \since 5.8.0
 */
//! \{
typedef struct {
    ScEncodingRange * encodings; //!< array of ranges
    uint32_t size; //!< number of elements in the array
} ScEncodingArray;
//! \}

/**
 * \brief Create new ScEncodingArray with given size
 *
 * \returns The created ScEncodingArray.
 *
 * \param size The array size.
 *
 * \since 5.8.0
 * \memberof ScEncodingArray
 */
SC_EXPORT ScEncodingArray
sc_encoding_array_new(uint32_t size);

/**
 * \brief Assigns the value of the element at index pos in the array.
 *
 * \param array The encoding array.
 * \param pos Index, may take any value 0 <= i < size of array.
 * \param encoding Encoding of the encoding range
 * \param start Start index in the data corresponding to the encoding range
 * \param end End index in the data corresponding to the encoding range
 *
 * \since 5.8.0
 * \memberof ScEncodingArray
 */
SC_EXPORT void
sc_encoding_array_assign(ScEncodingArray *array, uint32_t pos, const char * encoding, uint32_t start, uint32_t end);

/**
 * \brief Get the number of elements in the array.
 *
 * \returns The number of elements.
 *
 * \param array The encoding array.
 *
 * \since 5.0.0
 * \memberof ScEncodingArray
 */
SC_EXPORT uint32_t
sc_encoding_array_get_size(ScEncodingArray array);

/**
 * \brief Access an encoding range
 *
 * \returns the elements at position i
 *
 * \param array The encoding array.
 * \param i index in the array
 *
 * \since 5.0.0
 * \memberof ScEncodingArray
 */
SC_EXPORT ScEncodingRange
sc_encoding_array_get_item_at(ScEncodingArray array, uint32_t i);

/**
 * \brief Frees the data of the encoding array
 *
 * \param array The encoding array.
 *
 * \since 5.0.0
 * \memberof ScEncodingArray
 */
SC_EXPORT void
sc_encoding_array_free(ScEncodingArray array);

#if defined(__cplusplus)
}
#endif

#endif // SC_BYTE_ARRAY_H_
