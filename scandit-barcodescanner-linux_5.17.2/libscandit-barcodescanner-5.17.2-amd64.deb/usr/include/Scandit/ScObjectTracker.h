/**
 * \file ScObjectTracker.h
 *
 * \brief API for tracking objects across frames
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2016 Scandit AG. All rights reserved.
 */

#ifndef SC_OBJECT_TRACKER_H_
#define SC_OBJECT_TRACKER_H_

#include <Scandit/ScConfig.h>

#include <Scandit/ScRecognitionContext.h>
#include <Scandit/ScTrackedObject.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \struct ScObjectTracker
 *
 * \brief Opaque pointer type for an object tracker.
 */
//! \{
typedef struct ScOpaqueObjectTracker ScObjectTracker;

typedef void (*ScObjectTrackerEventFunc)(const ScTrackedObject *object, void *user_data);
typedef void (*ScObjectTrackerEventFuncLost)(ScTrackedObjectType type, uint32_t tracking_id, void *user_data);
typedef void (*ScObjectTrackerEventFuncPredicted)(uint32_t tracking_id, ScQuadrilateral quadrilateral, float dt, void *user_data);

/**
 * \brief Callback storage structure. Set a callback to NULL to ignore it.
 */
typedef struct {
    ScObjectTrackerEventFunc on_object_appeared;
    ScObjectTrackerEventFunc on_object_updated;
    ScObjectTrackerEventFuncLost on_object_lost;
    ScObjectTrackerEventFuncPredicted on_object_predicted;
} ScObjectTrackerCallbacks;

/**
 * \brief Create a new object tracker
 *
 * \param context The recognition context. Must not be null.
 * \param callbacks Set of callbacks to be invoked when a new objects are found, their position is updated, or they
 *     are lost. Must not be null, however, each of the callbacks may be null, if the user is not interested in receiving these events.
 * \param callback_user_data Optional pointer to user data which will be passed to the event functions as the second
 *    argument.
 * \return The new tracker object.
 *
 * \since 5.8.0
 */
SC_EXPORT ScObjectTracker *sc_object_tracker_new(ScRecognitionContext *context,
                                                 ScObjectTrackerCallbacks *callbacks,
                                                 void *callback_user_data);
/**
 * \brief Increase reference count of the object tracker
 * \param tracker Reference to the tracker. Must not be null
 *
 * \since 5.8.0
 */
SC_EXPORT void
sc_object_tracker_retain(ScObjectTracker *tracker);

/**
 * \brief Decrease reference count of tracker object
 * \param tracker Reference to the tracker. May be null.
 *
 * \since 5.8.0
 */
SC_EXPORT void
sc_object_tracker_release(ScObjectTracker *tracker);

/**
 * \brief Check if tracking is enabled or disabled
 * \param tracker Reference to the tracker. Must not be null
 * \return True when tracking is enabled, false if not
 *
 * \since 5.8.0
 */
SC_EXPORT ScBool
sc_object_tracker_is_enabled(const ScObjectTracker *tracker);

/**
 * \brief Enable or disable tracking
 * \param option True when tracking should be enabled, false if not
 * \param tracker Reference to the tracker. Must not be null
 *
 * \since 5.8.0
 */
SC_EXPORT void
sc_object_tracker_set_enabled(ScObjectTracker *tracker, ScBool option);

#if defined(__cplusplus)
}
#endif

#endif // SC_OBJECT_TRACKER_H_


