/**
 * \file ScByteArray.h
 * \brief Functions to manage an array of bytes
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_BYTE_ARRAY_H_
#define SC_BYTE_ARRAY_H_

#include "Scandit/ScConfig.h"

#if defined(__cplusplus)
extern "C" {
#endif


/**
 * \struct ScByteArray
 *
 * \brief A null terminated array of bytes
 *
 * The array is always terminated with a null-byte, but null-characters may appear in the
 * middle. Use sc_byte_array_get_size() to get the complete length of the data.
 *
 * \since 4.6.0
 */
//! \cond SuppressDoxygen
typedef struct {
    union {
        //! pointer to the byte representation
        const uint8_t *bytes;
        const uint8_t *data; //!< deprecated
        //! pointer to the string representation
        const char *str;
        const char *c_str; //!< deprecated
    };
    //!< number of bytes in the array
    union {
        uint32_t size;
        uint32_t length; //!< deprecated to length
    };
    uint32_t flags; //!< private flags
} ScByteArray;
//! \endcond

/**
 * \brief Get the number of bytes in the array.
 *
 * \returns The number of bytes.
 *
 * \param array The byte array.
 *
 * \since 4.6.0
 * \memberof ScByteArray
 */
SC_EXPORT uint32_t
sc_byte_array_get_size(ScByteArray array);

/**
 * \brief Get a const pointer to the byte data.
 *
 * \returns a constant pointer.
 *
 * \param array The byte array.
 *
 * \since 4.6.0
 * \memberof ScByteArray
 */
SC_EXPORT const uint8_t*
sc_byte_array_get_data(ScByteArray array);

/**
 * \brief Get a const string pointer to the array data.
 *
 * \returns a constant pointer.
 *
 * \param array The byte array.
 *
 * \since 4.6.0
 * \memberof ScByteArray
 */
SC_EXPORT const char*
sc_byte_array_get_string(ScByteArray array);

/**
 * Deallocates the array if its data is owned
 * \param array The byte array.
 *
 * \since 5.16.0
 */
SC_EXPORT void sc_byte_array_free(ScByteArray array);

#if defined(__cplusplus)
}
#endif

#endif // SC_BYTE_ARRAY_H_
