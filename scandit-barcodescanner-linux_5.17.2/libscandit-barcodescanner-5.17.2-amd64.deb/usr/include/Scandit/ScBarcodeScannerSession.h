/**
 * \file ScBarcodeScannerSession.h
 *
 * \brief Barcode Scanner Session
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 *
 */

#ifndef SC_BARCODE_SCANNER_SESSION_H_
#define SC_BARCODE_SCANNER_SESSION_H_

#include "ScBarcode.h"
#include "ScBarcodeArray.h"

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \struct ScBarcodeScannerSession
 *
 * \brief An opaque barcode scanner session object.
 *
 * The barcode scanner session keeps track of decoded and localized barcodes and
 * handles duplicate removal.
 *
 * <h2>Obtaining the barcode scanner session</h2>
 *
 * The barcode scanner session can be obtained at any time from a barcode scanner
 * object by calling sc_barcode_scanner_get_session(). The session contains the
 * decoded as well as localized barcodes after the last call to
 * sc_recognition_context_process_frame().
 *
 * <h2>Configuring Session Behaviour</h2>
 *
 * The scan session is responsible for determining the list of relevant barcodes
 * by filtering out duplicates. Depending on your app, different duplicate
 * removal is required. For some applications, only one barcode is required. The
 * scanning process is stopped as soon as one code is decoded. For other
 * applications, multiple codes are scanned after another. For example, a scanner
 * at the cash desk may need to scan multiple products. To avoid duplicates, the
 * same barcode should not be scanned in short succession. The same barcode (data,
 * symbology) should not count as a duplicate if encountered again after a few
 * seconds.
 *
 * By default, if a barcode has the same symbology and data as code that was
 * decoded less than 500ms ago, it is filtered out as a duplicate. The exact
 * filtering behaviour can be changed by setting the "code duplicate filter",
 * and "code caching duration" in ScBarcodeScannerSettings.
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueBarcodeScannerSession ScBarcodeScannerSession;
//! \}


/**
 * \brief Get list of recognized codes in the last processed frame.
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \return array of recognized barcodes. After use, the list must be released using
 *    sc_barcode_array_release().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT ScBarcodeArray *
sc_barcode_scanner_session_get_newly_recognized_codes(const ScBarcodeScannerSession *session);

/**
 * \brief Increase reference count of barcode scanner session by one.
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT void
sc_barcode_scanner_session_retain(ScBarcodeScannerSession *session);

/**
 * \brief Decrease reference count of barcode scanner session by one.
 *
 * When the reference count drops to zero, the barcode scanner session is deallocated.
 *
 * \param session The barcode scanner session object. May be null
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT void
sc_barcode_scanner_session_release(ScBarcodeScannerSession *session);

/**
 * \brief Get list of all recognized codes in the session.
 *
 * This function returns a list of all recognized codes currently contained in the session.
 * To only get codes recognized in the last frame, use
 * sc_barcode_scanner_session_get_newly_recognized_codes()
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \return array of recognized barcodes. After use, the list must be released using
 *    sc_barcode_array_release().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT ScBarcodeArray *
sc_barcode_scanner_session_get_all_recognized_codes(const ScBarcodeScannerSession *session);



/**
 * \brief Clear the barcode scanner session.
 *
 * This removes all recognized barcodes from the scanner session.
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT void
sc_barcode_scanner_session_clear(ScBarcodeScannerSession *session);

/**
 * \brief Get list of codes that were localized, but not recognized in the last processed frame.
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \return array of localized barcodes. After use, the list must be released using
 *    sc_barcode_array_release().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT ScBarcodeArray *
sc_barcode_scanner_session_get_newly_localized_codes(const ScBarcodeScannerSession *session);


/**
 * \brief Get unique ID of the last processed frame.
 *
 * \param session The barcode scanner session object. Must not be null.
 *
 * \return the frame id
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSession
 */
SC_EXPORT uint32_t
sc_barcode_scanner_session_get_last_processed_frame_id(const ScBarcodeScannerSession *session);


#if defined(__cplusplus)
}
#endif


#endif //SC_BARCODE_SCANNER_SESSION_H_


