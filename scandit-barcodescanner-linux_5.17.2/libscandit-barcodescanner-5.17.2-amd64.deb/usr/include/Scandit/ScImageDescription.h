/**
 * \file ScImageDescription.h
 * \brief Image Description interface
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_IMAGE_DESCRIPTION_H_
#define SC_IMAGE_DESCRIPTION_H_

#include <Scandit/ScConfig.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \brief Specifies the format of the pixel data.
 *
 * \since 4.6.0
 */
typedef enum {
    /**
     * \brief Image layout is unknown.
     */
    SC_IMAGE_LAYOUT_UNKNOWN         = 0x0000,
    /**
     * \brief Single-channel 8-bit gray scale image
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_GRAY_8U	        = 0x0001,
    /**
     * \brief RGB image with 8bit per color channel.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_RGB_8U		    = 0x0002,
    /**
     * \brief RGBA image with 8bit per color channel.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_RGBA_8U	        = 0x0004,

    /**
     * \brief ARGB image with 8bit per color channel.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_ARGB_8U         = 0x0100,

    /**
     * \brief YpCbCr 4:2:0 image format.
     *
     * A bi-planar format with separate Y and CbCr planes.
     *
     * When using this pixel layout the width, height, memory size as well as the number
     * of bytes per row and the offsets of both data planes must be set.
     */
    SC_IMAGE_LAYOUT_YPCBCR_8U	    = 0x0008,

    /**
     * \brief YpCrCb 4:2:0 image format.
     *
     * A bi-planar format with separate Y and CrCb planes.
     *
     * When using this pixel layout the width, height, memory size as well as the number
     * of bytes per row and the offsets of both data planes must be set.
     */
    SC_IMAGE_LAYOUT_YPCRCB_8U	    = 0x0010,

    /**
     * \brief 8-bit YUYV 4:2:2 image format.
     *
     * The Y, U and V samples are packed together in one image plane. UV are shared between
     * two adjacent pixels in a row.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_YUYV_8U		    = 0x0020,

    /**
     * \brief 8-bit UYVY 4:2:2 image format.
     *
     * The Y, U and V samples are packed together in one image plane. UV are shared between
     * two adjacent pixels in a row.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_UYVY_8U			= 0x0040,

    /**
     * \brief I420 format with separate Y, U and V planes
     *
     * The Y, U and V image planes are adjacent to each other. U and V are down-sampled
     * by 2x2, e.g. the U and V are shared for a 2x2 macro-block.
     *
     * When using this pixel layout the width/height and memory size properties of the
     * ScImageDescription must be set.
     */
    SC_IMAGE_LAYOUT_I420_8U         = 0x0080


} ScImageLayout;


/**
 * \struct ScImageDescription
 *
 * \brief Describes dimensions as well as internal memory layout of an image buffer.
 *
 * Depending on the image layout different properties must be set. All image layouts require at
 * least width, height and memory size. Bi-planar formats (\ref SC_IMAGE_LAYOUT_YPCRCB_8U,
 * \ref SC_IMAGE_LAYOUT_YPCBCR_8U) additionally require bytes per row as well as data plane offsets
 * for both planes.
 *
 * The following code snippet shows how to create an image description for an 8-bit grey-scale
 * image:
 *
 * \code
 *
 * ScImageDescription *desc = sc_image_description_new();
 * sc_image_description_set_width(640);
 * sc_image_description_set_height(480);
 * sc_image_description_set_memory_size(640 * 480);
 * sc_image_description_set_layout(SC_IMAGE_LAYOUT_GRAY_8U);
 *
 * \endcode
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueImageDescription ScImageDescription;
//! \}

/**
 * \brief Create a new image description
 *
 * All fields are initialized to zero and the image layout set to SC_IMAGE_LAYOUT_UNKNOWN.
 *
 * \return the newly created image description. After use, the image description must
 *      be released with sc_image_description_release().
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT ScImageDescription * sc_image_description_new(void);

/**
 * \brief Increase reference count of image description by one.
 *
 * \param description The image description object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_retain(ScImageDescription *description);

/**
 * \brief Decrease reference count of image description by one.
 *
 * When the reference count drops to zero, the image description is deallocated.
 *
 * \param description the description object. May be null.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_release(ScImageDescription *description);

/**
 * \brief Get the image layout.
 *
 * The image layout describes the format of the pixel data.  All values of ScImageLayout
 * are accepted.
 *
 * The default format is SC_IMAGE_LAYOUT_UNKNOWN.
 *
 * \param description the description object. Must not be null
 * \return returns the image description's image layout
 *
 * \return The image currently set image layout.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT ScImageLayout
sc_image_description_get_layout(const ScImageDescription *description);

/**
 * \brief Set the image layout.
 *
 * \param description the description object. Must not be null
 * \param layout the new image layout
 *
 * \see sc_image_description_get_layout
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_layout(ScImageDescription *description,
                                ScImageLayout layout);


/**
 * \brief Get width of image
 *
 * \param description the description object. Must not be null
 *
 * \return The width of the image in pixels.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_width(const ScImageDescription *description);

/**
 * \brief Set width of image
 *
 * \param description the description object. Must not be null
 *
 * \param width width in pixels
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_width(ScImageDescription *description,
                               uint32_t width);

/**
 * \brief Get height of image
 *
 * \param description the description object. Must not be null
 *
 * \return The height of the image in pixels.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_height(const ScImageDescription *description);

/**
 * \brief Set height of image
 *
 * \param description the description object. Must not be null
 * \param height height in pixels
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_height(ScImageDescription *description,
                                uint32_t height);


/**
 * \brief Get start offset of the first data plane.
 *
 * \param description the description object. Must not be null.
 *
 * \return The start offset of the first data plane.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_first_plane_offset(const ScImageDescription *description);


/**
 * \brief Set the start offset of the first data plane.
 *
 * \param description The description object. Must not be null.
 * \param offset The offset as measured from the beginning of the data buffer.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_first_plane_offset(ScImageDescription *description,
                                            uint32_t offset);

/**
 * \brief Get the number of bytes per row for the first data plane.
 *
 * \param description the description object. Must not be null
 *
 * \return The number of bytes per row.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_first_plane_row_bytes(const ScImageDescription *description);

/**
 * \brief Set the number of bytes per row for first data plane.
 *
 * \param description The description object. Must not be null.
 * \param row_bytes The number of bytes.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_first_plane_row_bytes(ScImageDescription *description,
                                               uint32_t row_bytes);


/**
 * \brief Get the number of bytes per row for the second data plane.
 *
 * \param description the description object. Must not be null
 *
 * \return The number of bytes per row of the second plane
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_second_plane_row_bytes(const ScImageDescription *description);

/**
 * \brief Set the number of bytes per row for the second data plane.
 *
 * \param description The description object. Must not be null.
 * \param row_bytes the number of bytes per row.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_second_plane_row_bytes(ScImageDescription *description,
                                                uint32_t row_bytes);


/**
 * \brief Get the start offset of the second data plane.
 *
 * \param description The description object. Must not be null.
 *
 * \return The start offset of the second data plane.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_second_plane_offset(const ScImageDescription *description);

/**
 * \brief Set the start offset of the second data plane.
 *
 * \param description The description object. Must not be null.
 * \param offset The number of bytes per row.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_second_plane_offset(ScImageDescription *description,
                                             uint32_t offset);

/**
 * \brief Get the total memory size of the frame data
 *
 * \param description the description object. Must not be null
 *
 * \return The total size of the image buffer in bytes.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT uint32_t
sc_image_description_get_memory_size(const ScImageDescription *description);

/**
 * \brief Set the total memory size of the frame data.
 *
 * \param description The description object. Must not be null.
 *
 * \param memory_size The total memory size of the frame data.
 *
 * \since 4.6.0
 * \memberof ScImageDescription
 */
SC_EXPORT void
sc_image_description_set_memory_size(ScImageDescription *description,
                                     uint32_t memory_size);


#if defined(__cplusplus)
}
#endif


#endif // SC_IMAGE_DESCRIPTION_H_


