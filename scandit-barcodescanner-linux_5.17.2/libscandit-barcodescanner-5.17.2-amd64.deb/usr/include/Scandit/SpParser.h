//------------------------------------------------------------------------------------------------//
//                        This file is part of the Scandit Parsing Library                        //
//                                                                                                //
//                   Copyright (c) 2016-2017 Scandit AG. All rights reserved                      //
//------------------------------------------------------------------------------------------------//

#ifndef SCANDIT_PARSER_PARSER_H
#define SCANDIT_PARSER_PARSER_H

#include <Scandit/Parser/SpCommon.h>
#include <Scandit/Parser/SpParserResult.h>
#include <Scandit/ScRecognitionContext.h>

SP_BEGIN_EXTERN_C

typedef struct SpOpaqueParser SpParser;

typedef enum {
    SP_PARSER_TYPE_GS1_AI = 1, //!< GS1 General Specifications standard, see http://www.gs1.org/
    SP_PARSER_TYPE_HIBC = 2,   //!< Health Industry Bar Code, see http://www.hibcc.org/
    SP_PARSER_TYPE_DLID = 3,   //!< DriverLicensing & Identification code, see http://www.aamva.org/
    SP_PARSER_TYPE_MRTD = 4,   //!< Machine Readable Travel Documents, see https://www.icao.int
    SP_PARSER_TYPE_SWISSQR = 5, //!< Swiss QR codes
    SP_PARSER_TYPE_VIN = 6,     //!< Vehicle Identification Number
    SP_PARSER_TYPE_US_USID = 7, //!< US Services ID, see https://www.cac.mil/
} SpParserType;

/**
 * Creates a parser if the license used by the context permits it.
 *
 * \param context a recognition context. Must not be null.
 * \param type type of the parser
 * \param status indicates errors during instantiation. Check this flag if the returned parser
 *               is a null pointer. Also, see \ref sc_context_status_flag_get_message and
 *               \ref ScContextStatusFlag for more information about status flags.
 * \return a parser object or null if the license does not include the parser
 */
SP_EXPORT SpParser *
sp_parser_new_with_context(ScRecognitionContext *context, SpParserType type,
                           ScContextStatusFlag *status);

/**
 * \brief Free the parser and associated resources
 *
 * \param parser The parser to free. May be null
 */
SP_EXPORT void sp_parser_free(SpParser *parser);

/**
 * \brief parse the data contained in the given string
 *
 * \return True on success, false if the data could not be parsed for some
 *      reason. In case of error, more details on why the parsing failed can be
 *      obtained by calling \ref sp_parse_result_get_error_message.
 */
SP_EXPORT SpBool
sp_parser_parse_string(SpParser *parser,
                       const char *str, size_t length,
                       SpParserResult **result);

/**
 * \brief Sets the options contained in the given json string
 *
 * \return the error message. If there were no errors, a NULL string is returned.
 *      The life-time of the string is not bound to the life-time of the parser
 *      object. The user has to free the SpData structure using sp_data_free.
 */
SP_EXPORT SpData
sp_parser_set_options(SpParser *parser, const char *str, size_t length);

SP_END_EXTERN_C

#endif // SCANDIT_PARSER_PARSER_H
