/**
 * \file ScBarcodeScannerSettings.h
 * \brief barcode scanner configuration
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_BARCODE_SCANNER_SETTINGS_H_
#define SC_BARCODE_SCANNER_SETTINGS_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScCommon.h>
#include <Scandit/ScBarcode.h>
#include <Scandit/ScSymbologySettings.h>

#if defined(__cplusplus)
extern "C" {
#endif


/**
 * \brief List of barcode scanner settings presets
 *
 * \since 4.6.0
 */
typedef enum  {
    /**
     * \brief Preset with all symbologies disabled
     */
    SC_PRESET_NONE = 0x00,
    /**
     * \brief Preset to enable decoding of all retail symbologies
     *
     * By using this preset, the decoding of the following symbologies is
     * enabled: EAN13, UPCA, EAN8, UPCE
     */
    SC_PRESET_ENABLE_RETAIL_SYMBOLOGIES = 0x01,
    /**
     * \brief Preset to enable decoding VIN codes
     *
     * This preset will enable scanning of the CODE39 symbology.
     */
    SC_PRESET_ENABLE_VIN_DECODING = 0x02,
    /**
     * \brief Preset to enable decoding SSCC18 codes
     *
     * This preset will enable scanning of CODE128 symbology.
     */
    SC_PRESET_ENABLE_SSCC_DECODING = 0x04,
    /**
     * \brief Preset that switches the scanner from real-time video stream processing to a single frame mode.
     *
     * This preset should only be used on fast devices. Execution time per frame can be up to a 100 times slower.
     *
     * \since 5.4.0
     */
    SC_PRESET_ENABLE_SINGLE_FRAME_MODE = 0x08

} ScBarcodeScannerSettingsPreset;

/**
 * \brief A bit-field of ScBarcodeScannerSettingsPreset
 */
typedef int32_t ScBarcodeScannerSettingsPresetFlags;


/**
 * \brief Enum for different code directions
 *
 * \since 4.6.0
 */
typedef enum {
    /**
     * Code orientation is unknown
     */
    SC_CODE_DIRECTION_NONE           = 0x00,
    /**
     * Code is oriented from left to right in the image
     */
    SC_CODE_DIRECTION_LEFT_TO_RIGHT  = 0x01,
    /**
     * Code is oriented from right to left in the image
     */
    SC_CODE_DIRECTION_RIGHT_TO_LEFT  = 0x02,
    /**
     * Code is oriented from top to bottom in the image
     */
    SC_CODE_DIRECTION_TOP_TO_BOTTOM  = 0x04,
    /**
     * Code is oriented from bottom to top in the image
     */
    SC_CODE_DIRECTION_BOTTOM_TO_TOP  = 0x08,

    /**
     * The code is oriented vertically in the image (top to bottom, or
     * bottom to top).
     */
    SC_CODE_DIRECTION_VERTICAL       = SC_CODE_DIRECTION_TOP_TO_BOTTOM | SC_CODE_DIRECTION_BOTTOM_TO_TOP,
    /**
     * The code is oriented horizontally in the image (left to right, or
     * right to left)
     */
    SC_CODE_DIRECTION_HORIZONTAL     = SC_CODE_DIRECTION_LEFT_TO_RIGHT | SC_CODE_DIRECTION_RIGHT_TO_LEFT
} ScCodeDirection;

/**
 * \brief Code location constraint.
 *
 * The code location constraint influences how the 1d and 2d code location areas are
 * interpreted.
 *
 * \since 4.6.0
 */
typedef enum {
   /**
    * \brief Restrict decoding to the specified area.
    *
    * Decoding of codes is restricted to this area.
    */
    SC_CODE_LOCATION_RESTRICT     = 0x01,
    /**
     * \brief The area indicates the most likely code position
     *
     * The area is a hint to the barcode scanner as to where codes can be found.
     */
    SC_CODE_LOCATION_HINT         = 0x02,
    /**
     * \brief The area can be defined but will not be used by the barcode scanner
     */
    SC_CODE_LOCATION_IGNORE       = 0x03
} ScCodeLocationConstraint;

/**
 * \struct ScBarcodeScannerSettings
 *
 * \brief An opaque data structure holding configuration options for the barcode scanner
 *
 * The barcode scanner settings influence how 1d and 2d codes are decoded by an
 * ScBarcodeScanner instance.
 *
 * For the settings to take effect they must be applied to the barcode scanner. This can
 * be done when the barcode scanner is created (sc_barcode_scanner_new_with_settings()),
 * or at a later stage with sc_barcode_scanner_apply_settings().
 *
 * <h1>Steps to Configure the Barcode Scanner</h1>
 *
 * * Create a new settings object starting from an empty configuration
 *   (sc_barcode_scanner_settings_new()), or using a combination of presets
 *   (sc_barcode_scanner_settings_new_with_preset()).
 * * Enable decoding of the required 1d and 2d symbologies using
 *   sc_barcode_scanner_settings_set_symbology_enabled().
 * * \b Optional: Set any additional symbology-specific settings on the symbology settings
 *   objects obtained by calling sc_barcode_scanner_settings_get_symbology_settings().
 * * \b Optional: If desired, configure the scan location (see below).
 *
 * <h1>Scan Location</h1>
 *
 * By default, 1d and 2d codes are searched in the full image. If it is known that codes
 * only appear in certain areas, or part of the camera feed is hidden below a UI element,
 * the localization can be restricted to certain parts of the image by setting the scan
 * area with sc_barcode_scanner_settings_set_search_area(). This setting affects both 1d
 * and 2d codes.
 *
 * To control scanning areas of 1d and 2d codes separately, set the 1d/2d code location
 * areas (sc_barcode_scanner_settings_set_code_location_area_1d(),
 * sc_barcode_scanner_settings_set_code_location_area_2d()). By default, these areas serve
 * as hints to the barcode scanner as to where codes are expected in the image (the code
 * location constraints are set to \ref SC_CODE_LOCATION_HINT). The scanner uses these
 * areas to give more weight to codes found in the code location areas. It is also possible
 * to completely turn off barcode localization and only use the 1d/2d code location areas.
 * This is done by setting the code location constraint to \ref SC_CODE_LOCATION_RESTRICT.
 *
 * <h2>Use Cases</h2>
 *
 * To illustrate how the scan area, 1d/2d code location areas and constraints work
 * together, we show configurations for common scanning scenarios.
 *
 * <b>Full Image Localization with preference to horizontal 1d codes: </b> This is the
 * default setting and not further configuration is required. The 1d code location area is
 * set to a centered strip 1/5 of of the image height running from the left to the right.
 * The code location constraint is set to \ref  SC_CODE_LOCATION_HINT, and the code direction
 * hint is \ref SC_CODE_DIRECTION_LEFT_TO_RIGHT.
 *
 * \code
 * ScBarcodeScannerSettings *settings = sc_barcode_scanner_settings_new();
 * sc_barcode_scanner_settings_set_code_location_area_1d(settings, sc_rectangle_f_make(0.f, 0.4f, 1.f, 0.2f));
 * sc_barcode_scanner_settings_set_code_location_constraint_1d(settings, SC_CODE_LOCATION_HINT);
 * sc_barcode_scanner_settings_set_code_direction_hint(settings, SC_CODE_DIRECTION_LEFT_TO_RIGHT);
 * \endcode
 *
 * <b>Laser UI Scanning: </b>To scan barcodes in a narrow band, set the 1d code location
 * area and use a 1d code location constraint of \ref SC_CODE_LOCATION_RESTRICT. You also
 * need to set the code direction hint to match the main direction of the narrow band. If
 * at the same time 2d codes are to be scanned, set the 2d code location area to a larger
 * rectangle.
 *
 * \code
 * ScBarcodeScannerSettings *settings = sc_barcode_scanner_settings_new();
 * sc_barcode_scanner_settings_set_code_location_area_1d(settings, sc_rectangle_f_make(0.f, 0.4f, 1.f, 0.2f));
 * sc_barcode_scanner_settings_set_code_location_constraint_1d(settings, SC_CODE_LOCATION_RESTRICT);
 * sc_barcode_scanner_settings_set_code_direction_hint(settings, SC_CODE_DIRECTION_LEFT_TO_RIGHT);
 * sc_barcode_scanner_settings_set_code_location_area_2d(settings, sc_rectangle_f_make(0.2f, 0.2f, 0.6f, 0.6f));
 * \endcode
 *
 * <h2>Code Duplicate Filter</h2>
 *
 * The barcode scanner session offers functionality to temporally filter codes of the
 * same symbology and encoding the same data scanned within a certain time interval. This
 * feature is turned off by default and can be configured through the barcode scanner
 * settings. It is enabled by
 *
 * - either setting the code duplicate filter (sc_barcode_scanner_settings_set_code_duplicate_filter())
 *   to -1, in which case the same code is not reported again until the session is cleared.
 * - or, setting the code duplicate filter to a value larger than 0, in which case the set
 *   values is the number of milliseconds in which the same code is not reported again as a
 *   new scan.
 *
 * Note that the code duplicate filter is further affected by the value of the code caching
 * duration. When the code caching duration is shorter than the code duplicate filter, the
 * duplicate filter is effectively limited to the code caching duration.
 *
 * <h2>Code Caching Duration</h2>
 *
 * By default, all codes that pass the duplicate filter are stored in the all recognized codes
 * list (sc_barcode_scanner_session_get_all_recognized_codes()). Because all of these codes
 * are stored in memory, the all recognized codes list can grow substantially when scanning
 * for a long time without calls to sc_barcode_scanner_session_clear(). Unless you have a
 * specific reason to keep all the codes in the all recognized codes list, it is recommended
 * to set the code caching duration to the same value as the code duplicate filter as this will
 * make sure that the codes get removed once they reach a certain age.
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueBarcodeScannerSettings ScBarcodeScannerSettings;
//! \}


/**
 * \brief Create a new barcode scanner settings object.
 *
 * This function is identical to using sc_barcode_scanner_settings_new_with_preset()
 * with  \ref SC_PRESET_NONE.
 *
 * \return the newly created barcode scanner settings object. The object must be released after
 *     use by calling sc_barcode_scanner_settings_release().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScBarcodeScannerSettings *sc_barcode_scanner_settings_new(void);

/**
 * \brief Create a new barcode scanner settings object.
 *
 * \param preset an ORed combination of ScBarcodeScannerSettingsPreset
 *
 * \return the newly created barcode scanner settings object. The object must be released after
 *     use by calling sc_barcode_scanner_settings_release().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScBarcodeScannerSettings *
sc_barcode_scanner_settings_new_with_preset(ScBarcodeScannerSettingsPresetFlags preset);

/**
 * \brief Create a new barcode scanner settings object from a json description
 *
 * \param json_data null-terminated JSON data string. The string is allowed to have comments
 *     as well as use single quotes instead of double quotes.
 * \param error in case the JSON data could not be parsed, error is filled with more details
 *     on the failure. In case of error, \p  error must be freed after use using
 *     \ref sc_error_free(). NULL may be used in case no further information on the error is
 *     required.
 *
 * \return the newly created barcode scanner settings object. NULL is returned in case the json
 *     data could not be parsed without errors. Check \p error for details.
 *
 * For a description of the JSON format undestood by this function, see \ref settings-json.
 *
 * \since 4.11.0
 *
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScBarcodeScannerSettings *
sc_barcode_scanner_settings_new_from_json(const char* json_data, ScError *error);

/**
 * \brief Increase reference count of barcode scanner settings.
 *
 * \param settings the barcode scanner settings object. Must not be null
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_retain(ScBarcodeScannerSettings *settings);

/**
 * \brief Decrease reference count of barcode scanner settings object by one
 *
 * When the reference count of the object drops to zero, it is deallocated.
 *
 * \param settings the barcode scanner settings object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_release(ScBarcodeScannerSettings *settings);


/**
 * \brief Creates and returns a deep copy of the barcode scanner settings object.
 *
 * \param settings The settings object to be copied/cloned. Must not be null.
 *
 * \return The cloned barcode scanner settings object with a reference count of
 *     one. After use, the barcode scanner settings object must be released with
 *     sc_barcode_scanner_settings_release().
 *
 * \since 4.7.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScBarcodeScannerSettings*
sc_barcode_scanner_settings_clone(ScBarcodeScannerSettings *settings);


/**
 * @name Custom Properties
 * @{
 */

/**
 * \brief Get custom properties.
 *
 * Custom properties are used for features of the barcode scanner that are not
 * yet part of the public API. As such they can disappear in one of the next
 * releases or change meaning.  Use with caution.
 *
 * Only properties of previous calls to sc_barcode_scanner_settings_set_property()
 * are returned here. When a property is not set, a default value is assumed.
 *
 * \param settings the settings object. Must not be null
 * \param key the name of the property
 *
 * \return The value of the property, or -1 if the property does not exist.
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT int32_t
sc_barcode_scanner_settings_get_property(const ScBarcodeScannerSettings *settings,
                                         const char* key);
/**
 * \brief Set custom properties.
 *
 * \param settings the settings object. Must not be null
 * \param key the name of the property
 * \param value the value to be set
 *
 * \see sc_barcode_scanner_settings_get_property
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_property(ScBarcodeScannerSettings *settings,
                                         const char* key, int32_t value);

/** @} */

/**
 * @name Symbology Settings
 * @{
 */

/**
 * \brief Enable/disable decoding of a certain symbology.
 *
 * This function provides a convenient shortcut to enabling/disabling decoding of a
 * particular symbology without having to go through ScSymbologySettings.
 *
 * \code
 * ScBarcodeScannerSettings* settings = ... ;
 * sc_barcode_scanner_settings_set_symbology_enabled(settings, SC_SYMBOLOGY_QR, SC_TRUE);
 *
 * // the following lines have the same effect:
 * ScSymbologySettings *sym_settings =
 *    sc_barcode_scanner_settings_get_symbology_settings(settings, SC_SYMBOLOGY_QR);
 * sc_symbology_settings_set_enabled(sym_settings, SC_TRUE);
 *
 * \endcode
 *
 * \param settings the barcode scanner settings object. Must not be null
 *
 * \param symbology the symbology to be enabled. Must be a valid symbology and equal
 *     to SC_SYMBOLOGY_UNKNOWN
 *
 * \param enabled true when decoding of the symbology should be enabled, false if
 *     not.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_symbology_enabled(ScBarcodeScannerSettings *settings,
                                                  ScSymbology symbology, ScBool enabled);
/**
 * \brief Retrieve symbology-specific settings.
 *
 * \param settings the barcode scanner settings object. Must not be null
 * \param symbology the symbology for which to retrieve the settings. Must be one of
 *     the valid symbology enums and not SC_SYMBOLOGY_UNKNOWN.
 *
 * \return the symbology-specific settings object. The object is owned by the
 *     barcode  scanner settings object and freed automatically when the
 *     barcode scanner settings object is freed.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScSymbologySettings *
sc_barcode_scanner_settings_get_symbology_settings(ScBarcodeScannerSettings *settings,
                                                   ScSymbology symbology);

/** @} */

/**
 * @name Code Count
 * @{
 */

/**
 * \brief Get the maximum number of barcode to be decoded every frame.
 *
 * \param settings the barcode scanner settings object. Must not be null
 *
 * \return the maximum number of codes per frame
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT uint32_t
sc_barcode_scanner_settings_get_max_number_of_codes_per_frame(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the maximum number of barcode to be decoded every frame.
 *
 * \param settings the barcode scanner settings object. Must not be null
 * \param max_codes the new maximum number of codes to be decoded every frame.
 *     Can not be set to zero.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_max_number_of_codes_per_frame(ScBarcodeScannerSettings *settings,
                                                              uint32_t max_codes);

/** @} */

/**
 * @name Search Area
 * @{
 */

/**
 * \brief Get the area of the image in which barcodes are searched.
 *
 * By default, barcodes are searched in the whole image.  By restricting the search area to
 * smaller areas the barcode scanner performance can be optimized.
 *
 * \param settings The barcode scanner settings object. Must not be null.
 *
 * \return the barcode scan area in relative coordinates. The top-left corner of the image
 *      is (0,0), the bottom right corner is (1, 1).
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScRectangleF
sc_barcode_scanner_settings_get_search_area(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the area of the image in which barcodes are searched.
 *
 * \param settings The barcode scanner settings object. Must not be null.
 * \param scan_area The new search area in relative coordinates.
 *
 * \see sc_barcode_scanner_settings_get_search_area
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_search_area(ScBarcodeScannerSettings *settings,
                                            ScRectangleF scan_area);

/** @} */

/**
 * @name Code Location
 * @{
 */

/**
 * \brief Get 1d code location area.
 *
 * \param settings the settings object. Must not be null
 * \return the code location hint in relative coordinates
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT ScRectangleF
sc_barcode_scanner_settings_get_code_location_area_1d(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set code location area for 1d codes.
 *
 * \param settings the settings object. Must not be null
 * \param rect the code location hint in relative coordinates
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_location_area_1d(ScBarcodeScannerSettings *settings,
                                                      ScRectangleF rect);

/**
 * \brief Get 1d code location constraint.
 *
 * \param settings the settings object. Must not be null.
 * \return The code location constraint
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT ScCodeLocationConstraint
sc_barcode_scanner_settings_get_code_location_constraint_1d(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the 1d code location constraint.
 *
 * \param settings The settings object. Must not be null.
 * \param constraint The code location constraint.
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_location_constraint_1d(ScBarcodeScannerSettings *settings,
                                                            ScCodeLocationConstraint constraint);

/**
 * \brief Get 2d code location area.
 *
 * \param settings the settings object. Must not be null
 * \return the code location hint in relative coordinates
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT ScRectangleF
sc_barcode_scanner_settings_get_code_location_area_2d(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set code location area for 2d codes.
 *
 * \param settings the settings object. Must not be null
 * \param rect the code location hint in relative coordinates
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_location_area_2d(ScBarcodeScannerSettings *settings,
                                                      ScRectangleF rect);

/**
 * \brief Get 2d code location constraint.
 *
 * \param settings the settings object. Must not be null
 * \return the code location hint in relative coordinates
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT ScCodeLocationConstraint
sc_barcode_scanner_settings_get_code_location_constraint_2d(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the 2d code location constraint.
 *
 * \param settings The settings object. Must not be null
 * \param constraint The code location constraint.
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_location_constraint_2d(ScBarcodeScannerSettings *settings,
                                                            ScCodeLocationConstraint constraint);

/** @} */

/**
 * @name Camera Focus
 * @{
 */

/**
 * \brief Get the camera's focus type.
 *
 * \param settings the settings object. Must not be null
 * \return the current focus type of the camera
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT ScCameraFocusMode
sc_barcode_scanner_settings_get_focus_mode(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the camera's focus type.
 *
 * \param settings the settings object. Must not be null.
 * \param focus_mode the focus type of the camera.
 *
 * \memberof ScBarcodeScannerSettings
 * \since 4.6.0
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_focus_mode(ScBarcodeScannerSettings *settings,
                                           ScCameraFocusMode focus_mode);

/** @} */

/**
 * @name Code Direction
 * @{
 */

/**
 * \brief Get the code direction hint.
 *
 * \param settings the barcode scanner settings object. Must not be null.
 *
 * \return The current code direction hint. The default is SC_CODE_DIRECTION_LEFT_TO_RIGHT.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT ScCodeDirection
sc_barcode_scanner_settings_get_code_direction_hint(const ScBarcodeScannerSettings *settings);

/**
 * \brief Set the code direction hint.
 *
 * The code direction hint tells the barcode scanner in what direction 1-dimensional codes
 * are most likely oriented. This hint is only useful for 1d (barcodes), and ignored for
 * 2d codes.
 *
 * The hint is in image coordinates. If you are scanning barcodes on a mobile device that supports
 * multiple device orientations, you will have to rotate the hint accordingly. For example if you
 * want to scan horizontal codes when the phone/device is in portrait mode, you will have to set
 * the code direction hint to SC_CODE_DIRECTION_BOTTOM_TO_TOP.
 *
 * \param settings The barcode scanner settings object. Must not be null.
 * \param direction The new code direction hint.
 * \see sc_barcode_scanner_settings_get_code_direction_hint
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_direction_hint(ScBarcodeScannerSettings *settings,
                                                    ScCodeDirection direction);


/** @} */

/**
 * @name Session Settings
 *
 * The session settings do not affect the object tracker (MatrixScan).
 * @{
 */

/**
 * \brief Get the code duplicate filter of the scan session.
 *
 * \see sc_barcode_scanner_settings_set_code_duplicate_filter
 *
 * Duplicate filtering affects the handling of codes with the same data and symbology
 * scanned within a certain, typically short, time interval. When the filter is set to -1,
 * each unique code is only added once to the session, when set to 0, duplicate filtering
 * is disabled. Otherwise the duplicate filter specifies an interval in milliseconds. When
 * the same code (data/symbology) is scanned within the specified interval is it filtered
 * out as a duplicate.
 *
 * By default, the code duplicate filter is disabled (set to 0). The code duplicate filter
 * is also affected by the code caching duration (see code caching duration section above).
 *
 * \param settings the settings object. Must no be null
 *
 * \return The current code duplicate filter.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT int32_t
sc_barcode_scanner_settings_get_code_duplicate_filter(const ScBarcodeScannerSettings *settings);

/**
 * \brief Specifies the duplicate filter to use for the session.
 *
 * \param settings the settings object. Must no be null
 * \param filter the new code duplicate filter
 *
 * The code duplicate filter settings only affect the scan session and do not affect the object tracker.
 *
 * \see sc_barcode_scanner_settings_get_code_duplicate_filter
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_duplicate_filter(ScBarcodeScannerSettings *settings,
                                                      int32_t filter);

/**
 * \brief Get the code caching duration of the scan session.
 *
 * When set to -1, codes are kept until the next call to sc_barcode_scanner_session_clear().
 * When set to 0, codes are kept until the next frame processing call finishes. For all other
 * values, code_caching_duration specifies a duration in milliseconds for how long the codes are
 * kept.
 *
 * The default value is -1.
 *
 * \param settings the settings object. Must not be null
 *
 * \return The code caching duration.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT int32_t
sc_barcode_scanner_settings_get_code_caching_duration(const ScBarcodeScannerSettings *settings);

/**
 * \brief Determines how long codes are kept in the session.
 *
 * \param settings the settings object. Must not be null
 * \param duration the code caching duration
 *
 * The code caching duration only affects the scan session and does not affect the object tracker.
 *
 * \see sc_barcode_scanner_settings_get_code_caching_duration
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_set_code_caching_duration(ScBarcodeScannerSettings *settings,
                                                      int32_t duration);

/** @} */

/**
 * \brief Returns the settings contained in the object as json.
 *
 * \param settings the settings object. Must not be null
 *
 * \return The settings serialized as JSON. After use the string must be freed by the caller using
 *    sc_free().
 *
 * \since 4.6.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT char*
sc_barcode_scanner_settings_as_json(const ScBarcodeScannerSettings *settings);



#if (SC_PLATFORM_IOS && defined(__OBJC__) && __OBJC__) || (defined(SC_GENERATE_DOCS) && SC_GENERATE_DOCS)

#include <UIKit/UIKit.h>
/**
 * \brief Configure barcode scanner settings for recognizing barcodes in the provided UIImage.
 *
 * Use this function for optimizing the barcode scanner settings for scanning barcodes with
 * \ref ScRecognitionContext::sc_recognition_context_process_image. The settings, e.g. recognition areas, code direction
 * hint etc. are modified in-place. This function does not enable any of the symbologies. You need
 * to explicitly enable the barcode symbologies that you would like to scan.
 *
 * \param settings The settings object to modify. Must not be null
 * \param image the image to optimize parameters for.
 *
 * \since 4.14.0
 * \memberof ScBarcodeScannerSettings
 */
SC_EXPORT void
sc_barcode_scanner_settings_setup_for_ui_image(ScBarcodeScannerSettings *settings, UIImage *image);

#endif

#if defined(__cplusplus)
}
#endif


#endif //SC_BARCODE_SCANNER_SETTINGS_H_


