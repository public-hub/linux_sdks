/**
 * \file ScBarcodeScanner.h
 *
 * \brief Barcode Scanner interface
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_BARCODE_SCANNER_H_
#define SC_BARCODE_SCANNER_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScRecognitionContext.h>
#include <Scandit/ScBarcodeScannerSettings.h>
#include <Scandit/ScBarcodeScannerSession.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \struct ScBarcodeScanner
 *
 * \brief Scans barcodes in images.
 *
 * The barcode scanner is the main interface for decoding barcodes in images. After
 * constructing a barcode scanner, barcodes are decoded when a frame is processed with
 * sc_recognition_context_process_frame().
 *
 * Barcode scanner results (decoded and localized barcodes) are available in the
 * "scan session" that can be retrieved by calling sc_barcode_scanner_get_session().
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueBarcodeScanner ScBarcodeScanner;
//! \}

/**
 * \brief Create a new barcode scanner instance with the given settings.
 *
 * \param context The recognition context. Must not be null.
 * \param settings The barcode scanner settings. Must not be null.
 *
 * \returns a new barcode scanner instance. After use, the instance must be freed with
 *     sc_barcode_scanner_release(). NULL is returned, if there is already
 *     another barcode scanner associated with this context.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT ScBarcodeScanner *
sc_barcode_scanner_new_with_settings(ScRecognitionContext *context,
                                     const ScBarcodeScannerSettings *settings);

/**
 * \brief Increase reference count of barcode scanner object by one.
 *
 * \param scanner The barcode scanner object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT void
sc_barcode_scanner_retain(ScBarcodeScanner *scanner);

/**
 * \brief Decrease reference count of barcode scanner by one.
 *
 * When the reference count drops to zero, the barcode scanner is deallocated.
 *
 * \param scanner The barcode scanner to release. May be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT void
sc_barcode_scanner_release(ScBarcodeScanner *scanner);


/**
 * \brief Get the current scanning session.
 *
 * The scanning session contains the current state of the barcode decoding
 * process, such as the codes that were decoded in the last frame.
 *
 * \param scanner The barcode scanner object. Must not be null
 *
 * \returns The session object. The session object is owned by the barcode
 *    scanner and is freed automatically when the barcode scanner
 *    is released. The returned session object is guaranteed to be non-null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT ScBarcodeScannerSession *
sc_barcode_scanner_get_session(ScBarcodeScanner *scanner);



/**
 * \brief Apply new settings.
 *
 * \param scanner The barcode scanner object. Must not be null.
 * \param settings The barcode scanner settings object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT void
sc_barcode_scanner_apply_settings(ScBarcodeScanner *scanner,
                                  const ScBarcodeScannerSettings *settings);

/**
 * \brief Checks whether the barcode scanner has completed initialization.
 *
 * \param scanner The barcode scanner object. Must not be null.
 *
 * \return True if setup has completed, false otherwise.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT ScBool
sc_barcode_scanner_is_setup_complete(const ScBarcodeScanner *scanner);

/**
 * \brief Block execution until the barcode scanner has completed setup.
 *
 * \param scanner The barcode scanner object. Must not be null.
 *
 * \return True on success, false otherwise.
 *
 * \since 4.6.0
 * \memberof ScBarcodeScanner
 */
SC_EXPORT ScBool
sc_barcode_scanner_wait_for_setup_completed(ScBarcodeScanner *scanner);


#if defined(__cplusplus)
}
#endif

#endif // SC_BARCODE_SCANNER_H_
