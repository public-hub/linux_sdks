/**
 * \file ScBarcode.h
 * \brief Functions for retrieving barcode information
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_BARCODE_H_
#define SC_BARCODE_H_

#include <Scandit/ScByteArray.h>
#include <Scandit/ScEncodingArray.h>
#include <Scandit/ScConfig.h>
#include <Scandit/ScCommon.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \enum ScSymbology
 *
 * \brief Enumeration of all supported 1d and 2d barcode symbologies
 *
 * \since 4.6.0
 */
typedef enum {
    /**
     * Sentinel value used whenever the symbology is unknown/undefined.
     */
    SC_SYMBOLOGY_UNKNOWN = 0x0000000,
    /**
     * EAN13
     */
    SC_SYMBOLOGY_EAN13 = 0x0000001,
    /**
     * EAN8
     */
    SC_SYMBOLOGY_EAN8 = 0x0000002,
    /**
     * UPCA
     */
    SC_SYMBOLOGY_UPCA = 0x0000004,
    /**
     * UPCE
     */
    SC_SYMBOLOGY_UPCE = 0x0000008,
    /**
     * Code128
     */
    SC_SYMBOLOGY_CODE128 = 0x0000010,
    /**
     * Code39
     */
    SC_SYMBOLOGY_CODE39 = 0x0000020,
    /**
     * Code93
     */
    SC_SYMBOLOGY_CODE93 = 0x0000040,
    /**
     * Interleaved 2 of 5 (ITF)
     */
    SC_SYMBOLOGY_INTERLEAVED_2_OF_5 = 0x0000080,
    /**
     * QR Code
     */
    SC_SYMBOLOGY_QR = 0x0000100,
    /**
     * Data Matrix
     */
    SC_SYMBOLOGY_DATA_MATRIX = 0x0000200,
    /**
     * PDF417
     */
    SC_SYMBOLOGY_PDF417 = 0x0000400,
    /**
     * MSI Plessey
     */
    SC_SYMBOLOGY_MSI_PLESSEY = 0x0000800,
    /**
     * GS1 DataBar
     */
    SC_SYMBOLOGY_GS1_DATABAR = 0x0001000,
    /**
     * GS1 DataBar Expanded
     */
    SC_SYMBOLOGY_GS1_DATABAR_EXPANDED = 0x0002000,
    /**
     * Codabar
     */
    SC_SYMBOLOGY_CODABAR = 0x0004000,
    /**
     * Aztec code
     */
    SC_SYMBOLOGY_AZTEC = 0x0008000,
    /**
     * EAN/UPC two-digit add-on
     *
     * Also known as EAN/UPC extension or supplemental code.
     */
    SC_SYMBOLOGY_TWO_DIGIT_ADD_ON = 0x0010000,
    /**
     * EAN/UPC five-digit add-on
     *
     * Also known as EAN/UPC extension or supplemental code.
     */
    SC_SYMBOLOGY_FIVE_DIGIT_ADD_ON = 0x0020000,
    /**
     * MaxiCode
     */
    SC_SYMBOLOGY_MAXICODE = 0x0040000,
    /**
     * Code 11
     */
    SC_SYMBOLOGY_CODE11 = 0x0080000,
    /**
     * Databar Limited
     */
    SC_SYMBOLOGY_GS1_DATABAR_LIMITED = 0x0100000,
    /**
     * Code25
     *
     * Also known as 'Industrial 2 of 5', 'Standard 2 of 5' or 'Discrete 2 of 5'
     */
    SC_SYMBOLOGY_CODE25 = 0x0200000,
    /**
     * Micro PDF417
     */
    SC_SYMBOLOGY_MICRO_PDF417 = 0x0400000,

    /**
     * Royal Mail 4 State Customer Code
     */
    SC_SYMBOLOGY_RM4SCC = 0x0800000,
    /**
     * KIX postal code symbology
     */
    SC_SYMBOLOGY_KIX = 0x1000000,
    /**
     * DotCode
     */
    SC_SYMBOLOGY_DOTCODE = 0x2000000,
    /**
     * Micro QR
     */
    SC_SYMBOLOGY_MICRO_QR = 0x4000000,
    /**
     * Italian Pharma Code (Code32)
     */
    SC_SYMBOLOGY_CODE32 = 0x8000000,
    /**
     * Posti LAPA (Lajittelupalvelu) 4 State Code
     */
    SC_SYMBOLOGY_LAPA4SC = 0x10000000,
    /**
     * IATA (International Air Transport Association) 2 of 5
     */
    SC_SYMBOLOGY_IATA_2_OF_5 = 0x20000000,

} ScSymbology;

/**
 * \enum ScCompositeFlag
 *
 * \brief Flags to hint that two codes form a composite code.
 *
 * \since 4.14.0
 */
typedef enum {
    /**
     * Code is not part of a composite code.
     */
    SC_COMPOSITE_FLAG_NONE               = 0x0000000,
    /**
     * Code could be part of a composite code. This flag is set by linear (1d) symbologies
     * that have no composite flag support but can be part of a composite code like the EAN/UPC
     * symbology family.
     */
    SC_COMPOSITE_FLAG_UNKNOWN            = 0x0000001,
    /**
     * Code is the linear component of a composite code. This flag can be set by
     * GS1 DataBar or GS1-128 (Code 128).
     */
    SC_COMPOSITE_FLAG_LINKED             = 0x0000002,
    /**
     * Code is a GS1 Composite Code Type A (CC-A). This flag can be set by MicroPDF417 codes.
     */
    SC_COMPOSITE_FLAG_GS1_A              = 0x0000004,
    /**
     * Code is a GS1 Composite Code Type B (CC-B). This flag can be set by MicroPDF417 codes.
     */
    SC_COMPOSITE_FLAG_GS1_B              = 0x0000008,
    /**
     * Code is a GS1 Composite Code Type C (CC-C). This flag can be set by PDF417 codes.
     */
    SC_COMPOSITE_FLAG_GS1_C              = 0x0000010
} ScCompositeFlag;

/**
 * \brief Array holding all symbologies supported by the scandit barcode scanner.
 *
 * The array has a total number of \ref SC_ALL_SYMBOLOGIES_COUNT elements.
 */
SC_EXPORT
SC_EXTERN const ScSymbology SC_ALL_SYMBOLOGIES[];

/**
 * \brief The number of elements in the \ref SC_ALL_SYMBOLOGIES array
 */
SC_EXPORT
SC_EXTERN const uint16_t SC_ALL_SYMBOLOGIES_COUNT;


/**
 * \brief Helper function to convert the symbology enum to a string
 *
 * \param symbology symbology id
 * \return pointer to a constant character array.
 *
 * \since 4.6.0
 */
SC_EXPORT const char* sc_symbology_to_string(ScSymbology symbology);


/**
 * \brief Helper function to convert a symbology string to its corresponding symbology enum
 *
 * \param symbology_string string with symbology name
 * \return the enum value for the given symbology string
 *
 * \since 5.5.0
 */
SC_EXPORT ScSymbology sc_symbology_from_string(const char *symbology_string);


/**
 * \struct ScBarcode
 *
 * \brief A located or recognized barcode/ 2d code in an image.
 *
 * Barcode objects represent 1d and 2d codes in images. They can either represent
 * barcodes that were completely decoded (recognized), or barcodes that were just
 * localized in the image.
 *
 * \since 4.6.0
 */
//! \{
typedef struct ScOpaqueBarcode ScBarcode;
//! \}

/**
 * \brief Get the data encoded in the barcode.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * The lifetime of the string is bound to the lifetime of the barcode object. It
 * is only safe to access the byte array as long as the barcode object exists, e.g.
 * before calling sc_barcode_release().
 *
 * The data of recognized barcodes is always terminated with a null-byte. For
 * symbologies that support encoding binary data, null-characters may appear in the
 * middle. Use sc_byte_array_get_size() to get the complete size of barcode
 * data for such symbologies.
 *
 * \returns The data encoded in the barcode. For barcodes that were located in the
 *    frame but not recognized, an empty array is returned.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT ScByteArray
sc_barcode_get_data(const ScBarcode *barcode);

/**
 * \brief Get the data encodings
 *
 * \param barcode The barcode object. Must not be null.
 *
 * The lifetime of the barcode data is bound to the lifetime of the barcode object. It
 * is only safe to access the encoding array as long as the barcode object exists, e.g.
 * before calling sc_barcode_release().
 *
 * The array itself has to be freed manually using sc_encoding_array_free().
 *
 * \returns The data encoding of the data in the barcode. For barcodes that were located in the
 *    frame but not recognized, an empty array is returned.
 *
 * \since 5.0.0
 * \memberof ScBarcode
 */
SC_EXPORT ScEncodingArray
sc_barcode_get_data_encoding(const ScBarcode *barcode);


/**
 * \brief Increase reference count of barcode object by one.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT void sc_barcode_retain(ScBarcode *barcode);

/**
 * \brief Decrease reference count of barcode object by one.
 *
 * When the reference count drops to zero, the barcode object is deallocated.
 *
 * \param barcode The barcode object. May be null.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT void sc_barcode_release(ScBarcode *barcode);


/**
 * \brief Get the symbology of the barcode.
 *
 * \param barcode the barcode object. Must not be null.
 *
 * \returns The symbology of the barcode. For barcodes that were located in the frame
 *      but not recognized, SC_SYMBOLOGY_UNKNOWN is returned.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT ScSymbology sc_barcode_get_symbology(const ScBarcode *barcode);

/**
 * \brief Check whether the barcode is a "GS1" code.
 *
 * \param barcode the barcode object. Must not be null
 *
 * \return True if the barcode is a GS1 code, false otherwise. In case
 *    sc_barcode_is_recognized() returns false, false is returned.
 *
 * A GS1 data carrier stores appication identifiers as defined by de GS1
 * General Specification.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT ScBool sc_barcode_is_gs1_data_carrier(const ScBarcode *barcode);

/**
 * \brief Flag to hint whether the barcode is part of a composite code.
 *
 * \param barcode the barcode object. Must not be null
 *
 * \return a single composite flag. If no barcode was recognized SC_COMPOSITE_FLAG_UNKNOWN
 * is returned.
 *
 * \since 4.14.0
 * \memberof ScBarcode
 */
SC_EXPORT ScCompositeFlag sc_barcode_get_composite_flag(const ScBarcode *barcode);

/**
 * \brief Check whether the barcode was fully decoded (recognized).
 *
 * \param barcode The barcode object. Must not be null.
 *
 * \return True for barcodes whose data was successfully decoded and
 *    false otherwise.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT ScBool sc_barcode_is_recognized(const ScBarcode *barcode);

/**
 * \brief Get the location of a recognized or located barcode.
 *
 * \return The location of the barcode in the image.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * The location is a polygon with 4 corners. The top_left corner corresponds to the
 * top-left in the coordinate system of the barcode. When the barcode stands "on the
 * head", e.g. it is decoded from right to left, the top_left corner corresponds to
 * the bottom-right corner in the image.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT ScQuadrilateral sc_barcode_get_location(const ScBarcode *barcode);

/**
 * \brief Get the frame ID a barcode was found in.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * \returns The frame ID of the image where the barcode was found in.
 *
 * \since 4.6.0
 * \memberof ScBarcode
 */
SC_EXPORT uint32_t sc_barcode_get_frame_id(const ScBarcode *barcode);

/**
 * \brief Get the symbol count of the barcode.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * \returns the symbol count or -1 if no symbol count exist for this symbology.
 *
 * \since 4.12.0
 * \memberof ScBarcode
 */
SC_EXPORT int32_t sc_barcode_get_symbol_count(const ScBarcode *barcode);

/**
 * \brief Get the color of the barcode.
 *
 * \param barcode The barcode object. Must not be null.
 *
 * \returns true if the barcode is white on black background. False indicates that the barcode is black on a white background or no barcode was found.
 *
 * \since 5.5.0
 * \memberof ScBarcode
 */
SC_EXPORT ScBool sc_barcode_is_color_inverted(const ScBarcode *barcode);

#if defined(__cplusplus)
}
#endif

#endif // SC_BARCODE_H_
