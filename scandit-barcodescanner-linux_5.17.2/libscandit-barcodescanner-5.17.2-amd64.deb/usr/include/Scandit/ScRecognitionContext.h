/**
 * \file ScRecognitionContext.h
 * \brief Recognition context interface
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_RECOGNITION_CONTEXT_H_
#define SC_RECOGNITION_CONTEXT_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScCommon.h>
#include <Scandit/ScImageDescription.h>

#if SC_PLATFORM_ANDROID
#include <jni.h>
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \struct ScRecognitionContext
 *
 * \brief Opaque recognition context data structure.
 *
 * The recognition context manages scanner objects of different types and takes care of scheduling
 * the recognition process. By default, the recognition context does not have any scanners. To
 * recognize a particular set of objects, the scanner object must be created. At the moment, the
 * only available scanner is the ScBarcodeScanner which recognizes 1d and 2d codes in images.
 *
 * To create a new recognition context a platform-specific function must be used. These functions
 * take care of license-management read the appropriate system properties to optimize the
 * recognition process for the device.
 */

//! \{
typedef struct ScOpaqueRecognitionContext ScRecognitionContext;
//! \}

/**
 * \brief Context status of a frame
 *
 * \since 4.6.0
 */
typedef enum {
    /**
     * \brief The context status is unknown.
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNKNOWN = 0,
    /**
     * \brief The context status is okay. No error occured.
     */
    SC_RECOGNITION_CONTEXT_STATUS_SUCCESS = 1,
    /**
     * \brief The context encountered an internal error.
     */
    SC_RECOGNITION_CONTEXT_STATUS_INTERNAL_ERROR = 2,
    /**
     * \brief Error code to indicate that sc_recognition_context_process_frame()
     * was called without a prior call to
     * sc_recognition_context_start_new_frame_sequence().
     */
    SC_RECOGNITION_CONTEXT_STATUS_FRAME_SEQUENCE_NOT_STARTED = 3,
    /**
     * \brief The provided image data is not supported by the recognition context.
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNSUPPORTED_IMAGE_DATA = 4,
    /**
     * \brief The provided image data has missing or inconsistent properties.
     * This error code can for example indicate that the data buffer size of the
     * provided image buffer is too small for the given combination of image
     * dimensions and format.
     */
    SC_RECOGNITION_CONTEXT_STATUS_INCONSISTENT_IMAGE_DATA = 5,
    /**
     * \brief Scandit SDK failed to get network access which is mandatory for
     * certain license types. For example a test license.
     *
     * Connect your device to the network, restart the application and try again.
     */
    SC_RECOGNITION_CONTEXT_STATUS_NO_NETWORK_CONNECTION = 6,
    /**
     * \brief The Scandit SDK license file expired. Please obtain a new one.
     *
     * \deprecated since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_FILE_EXPIRED = 7,
    /**
     * \brief The Scandit SDK license file can not be found or accessed.
     *
     * \deprecated since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_FILE_IO_ERROR = 8,
    /**
     * \brief Scandit SDK validation failed. Check your license key and network
     * connection.
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_VALIDATION_FAILED = 9,
    /**
     * \brief Scandit SDK detected a corrupted log and could not validate this
     * installation.
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_VALIDATION_FAILED_400 = 10,
    /**
     * \brief Scandit SDK validation failed. Make sure your app key is valid and
     * check your account for available device activations.
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_VALIDATION_FAILED_403 = 11,
    /**
     * \brief No Scandit SDK license key was set. Please set a valid license key
     * in your application.
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_KEY_MISSING = 12,
    /**
     * \brief The Scandit SDK validation failed. Your license key has expired.
     * Please login to scandit.com and aquire a new one.
     *
     * \since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_KEY_EXPIRED = 13,
    /**
     * \brief The Scandit SDK license validation failed. Your license key does not
     * include this platform. Please contact the Scandit support to request a
     * different license key.
     *
     * \since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_PLATFORM = 14,
    /**
     * \brief The Scandit SDK validation failed. Your app ID does not match the
     * license key's app ID. Please change the app identifier of your app or
     * acquire a new license key that matches your application identifier.
     *
     * \since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_APP_ID = 15,
    /**
     * \brief The Scandit SDK validation failed. Your license key does not include
     * support for this device. Please contact the Scandit support to request a
     * different license key.
     *
     * \since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_DEVICE = 16,
    /**
     * \brief The Scandit SDK validation failed. Your license key does not include
     * support for this SDK version. Please contact the Scandit support to request
     * a different license key.
     *
     * \since 4.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_SDK_VERSION = 17,
    /**
     * \brief The provided Scandit SDK license license key is invalid. Please set
     * a valid license key in your application.
     *
     * \since 5.1.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_LICENSE_KEY_INVALID = 18,
    /**
     * \brief The device activation failed. Please connect to the Internet and
     * restart the application.
     *
     * \since 5.6.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_DEVICE_ACTIVATION_FAILED = 19,
    /**
     * \brief The device activation failed. The number of allowed days to use the
     * SDK has exceeded.
     *
     * \since 5.9.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_TIME_EXCEEDED = 20,
    /**
     * \brief The device activation failed. The number of allowed scans has
     * exceeded.
     *
     * \since 5.9.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_SCANS_EXCEEDED = 21,
    /**
     * \brief The registration of the device is mandatory and must be completed
     * before the recognition context can be used.
     *
     * \since 5.9.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_REGISTRATION_MANDATORY_BUT_NOT_REGISTERED = 22,
    /**
     * \brief The Scandit SDK validation failed. The external id does not match
     * with the license key.
     *
     * \since 5.9.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_EXTERNAL_ID = 23,
    /**
     * \brief Your license does not include a symbology enabled by your barcode
     * scanner settings.
     *
     * \since 5.11.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_SYMBOLOGY_ENABLED = 24,
    /**
     * \brief Your license does not include the enabled resolution.
     *
     * \since 5.12.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_RESOLUTION = 25,
    /**
     * \brief Your license key's version is not compatible with this SDK version. Please contact Scandit support to request a different license key.
     *
     * \since 5.16.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_INVALID_LICENSE_KEY_VERSION = 26,
    /**
     * \brief Denotes the beginning of the enum range for unlicensed features
     *
     * When trying to use an unlicensed feature, the ScContextStatusFlag will be
     * set to an enum in the range from \ref
     * SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_FEATURE_BEGIN to \ref
     * SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_FEATURE_END. The exact value
     * depends on the unlicensed feature. To determine which feature is
     * unlicensed, use \ref sc_context_status_flag_get_message which will return a
     * human-readable representation of the error.
     *
     * \since 5.2.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_FEATURE_BEGIN = 255,

    /**
     * \brief Denotes the end of the enum range for unlicensed features
     *
     * \see SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_FEATURE_END
     *
     * \since 5.2.0
     */
    SC_RECOGNITION_CONTEXT_STATUS_UNLICENSED_FEATURE_END = 512,

} ScContextStatusFlag;

/**
 * \struct ScProcessFrameResult
 * \brief Result status and frame id.
 *
 * \since 4.6.0
 */
typedef struct {
    ScContextStatusFlag status; //!< Execution status flag
    uint32_t frame_id; //!< frame identification number within the current frame sequence
} ScProcessFrameResult;

/**
 * \brief Get a human readable error message for a result status.
 * \param status recognition context status flag
 * \returns a constant string message
 *
 * \since 4.12.0
 */
SC_EXPORT const char *
sc_context_status_flag_get_message(ScContextStatusFlag status);


#if SC_PLATFORM_ANDROID || (defined(SC_GENERATE_DOCS) && SC_GENERATE_DOCS)
/**
 * \brief Create a new recognition context (Android only).
 *
 * \param license_key Your license key, can't be NULL.
 * \param writable_data_path Path to a writable folder, can't be NULL.
 * \param env Pointer to the JNIEnv* object instance, can't be NULL.
 * \param activity Pointer to the activity object the recognition context is created in.
 * \param device_name Optional descriptive device name. Can be any string to track individual
 *   physical devices in Scanalytics. This parameter can be NULL to disable tracking.
 *
 * For performance reasons it is recommended that only one context per application is used.
 * If multiple contexts are created, make sure that context with different \a device_model_name
 * do not share the same \a writable_data_path.
 *
 * \return The newly created recognition context. After use, the context must be released
 *    by calling sc_recognition_context_release().
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT ScRecognitionContext *
sc_recognition_context_new(const char *license_key, const char* writable_data_path,
                           JNIEnv *env, jobject activity, const char* device_name);
#endif

#if SC_PLATFORM_IOS || (defined(SC_GENERATE_DOCS) && SC_GENERATE_DOCS)
/**
 * \brief Create a new recognition context (iOS only).
 *
 * \param license_key Your license key, can't be NULL.
 * \param device_name Optional descriptive device name. Can be any string to track individual
 *   physical devices in Scanalytics. This parameter can be NULL to disable tracking.
 *
 * For performance reasons it is recommended that only one context per application is used.
 * If multiple contexts are created, make sure that context with different \a device_model_name
 * do not share the same \a writable_data_path.
 *
 * \return The newly created recognition context. After use, the context must be released
 *    by calling sc_recognition_context_release().
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT ScRecognitionContext *
sc_recognition_context_new(const char *license_key, const char* device_name);
#endif

#if SC_PLATFORM_GENERIC || (defined(SC_GENERATE_DOCS) && SC_GENERATE_DOCS)
/**
 * \brief Recognition context constructor.
 *
 * \param license_key your license key, can't be NULL
 * \param writable_data_path path to a writable folder, can't be NULL
 * \param device_name a descriptive name or NULL
 *
 * \b Note: This constructor is not available on Android.
 *
 * The device_model_name parameter is used to optimize the algorithms for a certain hardware.
 * On iOS and Windows the official device ids should be used. E.g. 'iPhone5,1'.
 *
 * The device_name can be any string to track individual physical devices in Scanalytics.
 * This parameter can be NULL to disable tracking.
 *
 * For performance reasons it is recommended that only one context per application is used.
 * If multiple contexts are created, make sure that context with different \a device_model_name
 * do not share the same \a writable_data_path. Contexts with the same \a device_model_name can
 * share a \a writable_data_path.
 *
 * \return The newly created recognition context. After use, the context must be released
 *    by calling sc_recognition_context_release().
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT ScRecognitionContext *
sc_recognition_context_new(const char *license_key,
                           const char *writable_data_path,
                           const char *device_name);
#endif

/**
 * \brief Increase reference count of recognition context by one.
 *
 * \param context A valid context. Must not be null
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT void sc_recognition_context_retain(ScRecognitionContext *context);

/**
 * \brief Decrease reference count of recognition context by one.
 *
 * When the reference count drops to zero, the recognition context is deallocated.
 *
 * \param context A valid context. May be null
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT void sc_recognition_context_release(ScRecognitionContext *context);

/**
 * \brief Start processing a new batch of continuous frames.
 *
 * Call this function to inform the recognition context that a new sequence of frames starts. The
 * recognition context can assume that frames passed to sc_recognition_context_process_frame()
 * have temporal consistency and can use it to optimize the recognition processs. To indicate
 * discontinuities between frames, e.g. when resuming the camera after a pause, use
 * sc_recognition_context_end_frame_sequence() followed by
 * sc_recognition_context_start_new_frame_sequence().
 *
 * This function must be called once before sc_recognition_context_process_frame().
 *
 * The following example shows how to process an individual image:
 *
 * \code
 * ScRecognitionContext *context = ...;
 * ScImageDescription *image_description = ...;
 * uint8_t* image_data = ...;
 * sc_recognition_context_start_new_frame_sequence(context);
 * sc_recognition_context_process_frame(context, image_description, image_data);
 * sc_recognition_context_end_frame_sequence(context);
 * \endcode
 *
 * \param context A valid context. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT void
sc_recognition_context_start_new_frame_sequence(ScRecognitionContext *context);

/**
 * \brief Process image frame with this recognition context.
 *
 * The image is processed by the scanners associated with this context. The results,
 * for example the recognized barcodes, can be accessed directly on the scanner objects.
 *
 * Although you can pass in images of any size, and use any of the image layouts defined
 * in \ref ScImageLayout, the recognition context and the associated scanners have been
 * optimized for images that are approximately 1280x720 pixels in size and have a
 * continuous gray-channel. These pixel formats include \ref SC_IMAGE_LAYOUT_GRAY_8U,
 * \ref SC_IMAGE_LAYOUT_YPCBCR_8U, and \ref SC_IMAGE_LAYOUT_YPCRCB_8U.
 *
 * \param context A valid context. Must not be null.
 * \param image_description Input image description pointer. Must not be null.
 * \param image_data Input image data pointer. Must not be null.
 * \returns A structure holding a unique identifier for the processed frame and a process frame
 *      status code. The value of status code is:
 *      - \ref SC_RECOGNITION_CONTEXT_STATUS_SUCCESS when the frame was processed
 *        without error.
 *      - \ref SC_RECOGNITION_CONTEXT_STATUS_INCONSISTENT_IMAGE_DATA when not all
 *        required properties for the image descriptions' layout are provided.
 *      - \ref SC_RECOGNITION_CONTEXT_STATUS_FRAME_SEQUENCE_NOT_STARTED when
 *        sc_recognition_context_process_frame() is called without a prior call to
 *        sc_recognition_context_start_new_frame_sequence().
 *      - \ref SC_RECOGNITION_CONTEXT_STATUS_INTERNAL_ERROR when the recognition
 *        context encountered an internal error.
 *
 * \see sc_barcode_scanner_get_session
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT ScProcessFrameResult
sc_recognition_context_process_frame(ScRecognitionContext *context,
                                     const ScImageDescription *image_description,
                                     const uint8_t *image_data);

/**
 * \brief Signal that a batch of continuous frames ended.
 *
 * Use this function to indicate the end of a group of continuous frames. This function
 * will automatically be called when the recognition context is deallocated.
 *
 * \param context A valid context. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT void
sc_recognition_context_end_frame_sequence(ScRecognitionContext *context);

/**
 * \brief Set the geographical location.
 *
 * Set the location at which the device currently is according to its location services.
 * This is optional information, which, when provided, is transmitted to Scanalytics.
 *
 * \param context A valid context. Must not be null
 * \param latitude the latitude (north) in WGS84 coordinates.
 * \param longitude the longitude (east) in WGS84 coordinates.
 *
 * The coordinate for Zurich, Switzerland would be 47.366667, 8.55.
 *
 * \since 4.6.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT void
sc_recognition_context_set_geographical_location(ScRecognitionContext *context,
                                                 float latitude, float longitude);

#if (SC_PLATFORM_IOS && defined(__OBJC__) && __OBJC__) || (defined(SC_GENERATE_DOCS) && SC_GENERATE_DOCS)
#include <UIKit/UIKit.h>

/**
 * \brief Process image frame with this recognition context.
 *
 * The image is processed by the scanners associated with this context. The results,
 * for example the recognized barcodes, can be accessed directly on the scanner objects.
 *
 * Make sure to use sc_barcode_scanner_session_get_all_recognized_codes() when scanning
 * barcodes, since the image may be processed multiple times and only the results of the last
 * are available in sc_barcode_scanner_session_get_newly_recognized_codes().
 *
 * \param context A valid context. Must not be null.
 * \param image Input image. Must not be null.
 * \returns the status of the recognition context.
 *
 * \see sc_barcode_scanner_get_session
 *
 * \since 4.14.0
 * \memberof ScRecognitionContext
 */
SC_EXPORT ScContextStatusFlag
sc_recognition_context_process_image(ScRecognitionContext *context,
                                     UIImage *image);

#endif

#if defined(__cplusplus)
}
#endif

#endif // SC_RECOGNITION_CONTEXT_H_
