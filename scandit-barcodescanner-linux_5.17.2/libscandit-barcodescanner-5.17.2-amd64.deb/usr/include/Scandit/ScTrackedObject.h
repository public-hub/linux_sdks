/**
 * \file ScTrackedObject.h
 *
 * \brief API for tracking objects across frames
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2016 Scandit AG. All rights reserved.
 */

#ifndef SC_TRACKED_OBJECT_H_
#define SC_TRACKED_OBJECT_H_

#include <Scandit/ScConfig.h>

#include <Scandit/ScRecognitionContext.h>
#include <Scandit/ScBarcode.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \brief Type of the tracked object.
 */
typedef enum {
    /**
     * The tracked object is a barcode (may or may not be recognized). In case of a unrecognized barcode, no data or
     * symbology is associated with the object, only the location is known.
     */
    SC_TRACKED_OBJECT_TYPE_BARCODE = 0x01,
} ScTrackedObjectType;

/**
 * \struct ScTrackedObject
 *
 * \brief Opaque pointer type for an object tracker.
 *
 */
//! \{
typedef struct ScOpaqueTrackedObject ScTrackedObject;
//! \}

/**
 * \brief Get type of the tracked object.
 *
 * \param object Object for which to retrieve the type. Must not be null.
 * \return The type of the object.
 *
 * \since 5.8.0
 * \memberof ScTrackedObject
 */
SC_EXPORT ScTrackedObjectType
sc_tracked_object_get_type(const ScTrackedObject *object);

/**
 * \brief Retrieve unique id for the tracked object.
 *
 * The id is unique for each type of object, e.g. for barcodes. The same id may be reused once the object is lost
 * for another object.
 *
 * \param object The object for which to retrieve the id. Must not be null.
 * \return The unique id.
 *
 * \since 5.8.0
 * \memberof ScTrackedObject
 */
SC_EXPORT uint32_t
sc_tracked_object_get_id(const ScTrackedObject *object);

/**
 * \brief Get the location quadrilateral of the tracked object.
 *
 * \param object The tracked object. Must not be null.
 * \returns the quadrilateral of the object location.
 *
 * \since 5.8.0
 * \memberof ScTrackedObject
 */
SC_EXPORT ScQuadrilateral
sc_tracked_object_get_location(const ScTrackedObject *object);

/**
 * \brief Get the tracked barcode object.
 *
 * \param object The tracked object. Must not be null.
 * \returns the tracked barcode object or null if the object is not a barcode.
 *
 * \since 5.16.0
 * \memberof ScTrackedObject
 */
SC_EXPORT ScBarcode *sc_tracked_object_get_barcode(const ScTrackedObject *object);

/**
 * \brief Decrease reference count of tracked  object by one.
 *
 * When the reference count drops to zero, the tracked object is deallocated.
 *
 * \param object The tracked object. May be null.
 *
 * \since 5.9.0
 * \memberof ScTrackedObject
 */
SC_EXPORT void
sc_tracked_object_release(ScTrackedObject *object);

/**
 * \brief Increase reference count of the tracked object by one.
 *
 * \param object The tracked object. Must not be null.
 *
 * \since 5.9.0
 * \memberof ScTrackedObject
 */
SC_EXPORT void
sc_tracked_object_retain(ScTrackedObject *object);

#if defined(__cplusplus)
}
#endif

#endif // SC_TRACKED_OBJECT_H_
