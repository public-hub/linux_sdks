//------------------------------------------------------------------------------------------------//
//                        This file is part of the Scandit Parsing Library                        //
//                                                                                                //
//                   Copyright (c) 2016-2017 Scandit AG. All rights reserved                      //
//------------------------------------------------------------------------------------------------//

#ifndef SCANDIT_PARSER_PARSER_RESULT_H
#define SCANDIT_PARSER_PARSER_RESULT_H


#include <Scandit/Parser/SpCommon.h>

SP_BEGIN_EXTERN_C

typedef struct SpOpaqueParserResult SpParserResult;
typedef struct SpOpaqueField SpField;


/**
 * \brief Free the parsing result and any resource associated with it, including all its fields.
 *
 * \param result The parsing result. May be null.
 */
SP_EXPORT void sp_parser_result_free(SpParserResult *result);

/**
 * \brief Get number of fields of this result.
 *
 * \param result The parser result. Must not be NULL.
 *
 * \returns The number of fields
 */
SP_EXPORT size_t sp_parser_result_get_fields_count(const SpParserResult *result);

/**
 * \brief Get the data associated with a field
 *
 * \param result The parser result. Must not be NULL.
 * \param field_name The field name. Must not be NULL.
 *
 * \returns The data associated to the given field. In case no field of the
 * 		given name exists, NULL is returned.
 * \since 1.0.0
 */
SP_EXPORT const SpField* sp_parser_result_get_field_by_name(const SpParserResult *result, const char* field_name);

/**
 * \brief Get the data associated with a field
 *
 * \param result The parsing result. Must not be NULL.
 * \param field_name The field index.
 *
 * \returns The data associated to the given field. In case the field index is
 * 		out of range, NULL is returned.
 * \since 1.0.0
 */
SP_EXPORT const SpField* sp_parser_result_get_field_by_index(const SpParserResult *result, size_t index);

/**
 * \brief Returns true when result contains a valid result, false if an error
 * 		occurred during parsing.
 *
 * \param result The parsing result. Must not be NULL.
 */
SP_EXPORT SpBool sp_parser_result_is_ok(const SpParserResult *result);

/**
 * \brief Retrieve error message from parser result.
 *
 * In case there were no errors, a NULL string is returned.
 *
 * \param result The parser result. Must not be NULL.
 * \returns the error message. The life-time of the string is not bound to the
 * 		life-time of the of the parser result. The user has to free the SpData
 * 		structure using sp_data_free.
 */
SP_EXPORT SpData sp_parser_result_get_error_message(const SpParserResult *result);

/**
 * \brief Returns the json string value of the fields in a result
 *
 * \param result The parser result. Must not be NULL. The life-time of the
 *      string is bound to the life-time of the parser result. The user has to
 *      free the SpData structure using sp_data_free. Returns NULL if the
 *      result is NULL.
 */
SP_EXPORT SpData sp_parser_result_get_json_values(const SpParserResult *result);

/**
 * \brief Returns the name of the given field.
 *
 * \param field The field. Must not be NULL. The life-time of the string is
 * 		bound to the life-time of the field. The user has to free the
 * 		SpData structure using sp_data_free.
 */
SP_EXPORT SpData sp_field_get_name(const SpField *field);

/**
 * \brief Returns the string value of the given field.
 *
 * \param field The field. Must not be NULL. The life-time of the string is
 * 		bound to the life-time of the field. The user has to free the
 * 		SpData structure using sp_data_free.
 */
SP_EXPORT SpData sp_field_get_string_value(const SpField *field);

/**
 * \brief Returns the json representation of the given field.
 *
 * \param field The field. Must not be NULL. The life-time of the string is
 * 		bound to the life-time of the field. The user has to free the
 * 		SpData structure using sp_data_free.
 */
SP_EXPORT SpData sp_field_get_json_values(const SpField *field);

/**
 * \brief Returns issue string at the given index
 *
 * \param field The field. The life-time of the vector is
 * 		bound to the life-time of the field. The user has to free the
 * 		SpData structure using sp_data_free.
 * \param index The index. Position of issue string to be returned.
 */
SP_EXPORT SpData sp_field_get_issue(const SpField *field, uint32_t index);

/**
 * \brief Returns number of issues for the given field.
 *
 * \param field The field. The life-time of the vector is
 * 		bound to the life-time of the field. The user has to free the
 * 		SpData structure using sp_data_free.
 */
SP_EXPORT size_t sp_field_get_issues_count(const SpField *field);

SP_END_EXTERN_C

#endif // SCANDIT_PARSER_PARSER_RESULT_H
