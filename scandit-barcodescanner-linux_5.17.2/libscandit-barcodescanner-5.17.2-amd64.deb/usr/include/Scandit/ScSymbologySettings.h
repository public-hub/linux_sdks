/**
 * \file ScSymbologySettings.h
 *
 * \brief Barcode symbology configuration
 *
 * \ingroup publicapi
 *
 * \copyright Copyright (c) 2015 Scandit AG. All rights reserved.
 */

#ifndef SC_SYMBOLOGY_SETTINGS_H_
#define SC_SYMBOLOGY_SETTINGS_H_

#include <Scandit/ScConfig.h>
#include <Scandit/ScBarcode.h>

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \enum ScChecksum
 *
 * \brief A list of possible checksum algorithms.
 *
 * \since 4.6.0
 */
typedef enum {
    /**
     * \brief No checksum algorithm
     */
    SC_CHECKSUM_NONE      = 0x00,
    /**
     * \brief Checksum is calculating using modulo of 10
     */
    SC_CHECKSUM_MOD_10    = 0x01,
    /**
     * \brief Checksum is calculating using modulo of 11
     */
    SC_CHECKSUM_MOD_11    = 0x02,
    /**
     * \brief Checksum is calculating using modulo of 47
     */
    SC_CHECKSUM_MOD_47    = 0x04,
    /**
     * \brief Checksum is calculating using modulo of 103
     */
    SC_CHECKSUM_MOD_103   = 0x10,
    /**
     * \brief Two modulo 10 checksums.
     */
    SC_CHECKSUM_MOD_1010  = 0x20,
    /**
     * \brief Modulo 11 and a modulo 10 checksum.
     */
    SC_CHECKSUM_MOD_1110  = 0x40,
    /**
     * \brief Modulo 43 checksum, e.g. as used by Code39
     */
    SC_CHECKSUM_MOD_43    = 0x100,
    /**
     * \brief Modulo 16 checksum, e.g. as used by Codabar
     */
    SC_CHECKSUM_MOD_16 = 0x200,
} ScChecksum;

/**
 * \brief A bit-wise combination of ScChecksum.
 */
typedef int32_t ScChecksums;

/**
 * \struct ScSymbologySettings
 *
 * \brief Contains symbology-specific settings.
 */

//! \{
typedef struct ScOpaqueSymbologySettings ScSymbologySettings;
//! \}

/**
 * \brief Get symbology of the symbology settings object.
 *
 * \param settings The settings object. Must not be null.
 *
 * \return The symbology of the symbology settings object.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT ScSymbology
sc_symbology_settings_get_symbology(const ScSymbologySettings *settings);

/**
 * \brief Increase reference count of barcode symbology settings by one.
 *
 * \param settings The settings object. Must not be null.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_retain(ScSymbologySettings *settings);

/**
 * \brief Decrease reference count of barcode symbology settings by one.
 *
 * When the reference count drops to zero, the symbology settings object is deallocated.
 *
 * \param settings The settings object. May be null.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_release(ScSymbologySettings *settings);

/**
 * @name Enable/Disable Decoding
 * @{
 */
/**
 * \brief Determine whether decoding of this symbology is enabled.
 *
 * By default decoding of all symbologies is disabled. To enable decoding of a symbology,
 * use sc_symbology_settings_set_enabled(). It is advised to only enable symbologies
 * that are required by the application as every enabled symbology adds processing overhead.
 *
 * This function only enables decoding of dark codes on bright background. If color-inverted
 * (bright on dark) codes for this symbology are required, enable them using
 * sc_symbology_settings_set_color_inverted_enabled()
 *
 * \param settings The settings object. Must not be null.
 *
 * \returns returns true when decoding of codes of this symbology is enabled, false
 *     otherwise.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT ScBool
sc_symbology_settings_is_enabled(const ScSymbologySettings *settings);

/**
 * \brief Enable/disable decoding of this symbology.
 *
 * This function only enables/disables decoding of dark codes on bright background. If color-
 * inverted (bright on dark) codes for this symbology are required, enable them using
 * sc_symbology_settings_set_color_inverted_enabled()
 *
 * \param settings The settings object. Must not be null.
 * \param enabled Whether to enable decoding of this symbology.
 *
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_set_enabled(ScSymbologySettings *settings,
                                  ScBool enabled);

/**
 * \brief Determine whether color-inverted decoding of this symbology is enabled.
 *
 * By default color-inverted decoding of all symbologies is disabled. To enable decoding of
 * use sc_symbology_settings_set_color_inverted_enabled(). It is advised to only enable
 * symbologies that are required by the application as every enabled symbology adds processing
 * overhead.
 *
 *
 * \param settings The settings object. Must not be null.
 *
 * \returns True when decoding of codes of this symbology is enabled, false
 *     otherwise.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT ScBool
sc_symbology_settings_is_color_inverted_enabled(const ScSymbologySettings *settings);

/**
 * \brief Enable/disable decoding of this symbology.
 *
 * This function only enables/disables decoding of bright codes on dark background.
 *
 * \param settings The settings object. Must not be null.
 * \param enabled Whether to enable decoding of this symbology.
 *
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_set_color_inverted_enabled(ScSymbologySettings *settings,
                                                 ScBool enabled);

/**
 * @name Checksums
 * @{
 */

/**
 * \brief Get active optional checksums of this symbology.
 *
 * This function returns a bit-field of active checksums. When a barcode has been decoded,
 * the checksums returned  are evaluated in addition to any mandatory checksum defined by
 * the symbology specification. If any of the checksums matches, the code is returned as
 * recognized, otherwise it is discarded.
 *
 * Note that most symbologies do not allow any optional checksums.
 *
 * \param settings the settings object. Must not be null.
 * \returns bit field of active checksums.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 *
 */
SC_EXPORT ScChecksums
sc_symbology_settings_get_checksums(const ScSymbologySettings *settings);

/**
 * \brief Set active optional checksums for this symbology.
 *
 * This function allows to set additional checksums for this symbology.
 *
 * \param settings The settings object. Must not be null.
 * \param checksums Bit-wise combination of ScChecksum values.
 * \see sc_symbology_settings_get_checksums
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 *
 */
SC_EXPORT void
sc_symbology_settings_set_checksums(ScSymbologySettings *settings,
                                    ScChecksums checksums);

/** @}*/

/**
 * @name Extensions
 * @{
 */

/**
 * \brief Determine whether a certain extension is enabled for the symbology.
 *
 * Extensions are custom features that are only supported by a small number of
 * symbologies. For a list of supported extensions, consult \ref symbologies.
 *
 * \param settings The settings object. Must not be null.
 * \param extension Name of the extension.
 *
 * \return True if the extension is enabled, false if not.
 *
 * See \ref symbologies for a list of all available extensions.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT ScBool
sc_symbology_settings_is_extension_enabled(const ScSymbologySettings *settings,
                                           const char *extension);


/**
 * \brief Activate/Deactivate a custom extension for the symbology.
 *
 * Extensions are custom features that are only supported by a small number of
 * symbologies. For a list of supported extensions, consult \ref symbologies.
 *
 * \param settings The settings object. Must not be null.
 * \param extension Name of the extension.
 * \param enabled Whether the extension should be enabled/disabled.
 *
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_set_extension_enabled(ScSymbologySettings *settings,
                                            const char *extension, ScBool enabled);

/**
 * \brief Get all enabled extensions for this symbology
 *
 * \param settings The settings object. Must not be null.
 * \returns A null-terminated array containing the enabled extensions. The array as well as the individual
 *    strings must be freed with \ref sc_free once they are not used anymore.
 *
 * \since 4.16.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT char **
sc_symbology_settings_get_enabled_extensions(ScSymbologySettings *settings);

/** @}*/

/**
 * @name Control Length of Decoded Barcodes
 * @{
 */

/**
 * \brief This function allows to control the length of barcodes to be decoded.
 *
 * Call this function to enable decoding of long codes which can not be decoded with the default
 * settings, or to optimize decoder performance for codes of certain lengths. This is useful when
 * it is known that the application only requires scanning of particular barcode lengths.
 *
 * The mapping from characters to symbols is symbology-specific. For some symbologies, the start
 * and end characters are included, others include checksums characters in the symbol counts.
 *
 * The active symbol count setting is ignored for fixed-size barcodes (the EAN and UPC family of
 * codes) as well as 2d codes. For other symbologies, see \ref symbologies for a list of supported
 * symbol counts, and \ref calculate-symbol-counts.
 *
 * Symbol counts that are outside of the supported symbol count range are ignored.
 *
 * \param settings The settings object. Must not be null.
 * \param active_counts Pointer to a non-empty array of active counts.
 * \param num_counts The number of elements in active_counts.
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_set_active_symbol_counts(ScSymbologySettings * settings, const uint16_t *active_counts,
                                               uint16_t num_counts);

/**
 * \brief Retrieve the current active symbol counts of this symbology
 *
 * For a description of what active symbol counts are, refer to sc_symbology_settings_set_active_symbol_counts()
 *
 * \param settings The settings object. Must not be null.
 * \param active_counts Pointer to array of active counts. When the function returns, the array contains
 *    the active symbol counts for this symbology. After use, the array must be freed with sc_free. Null may be
 *    passed for this argument in which case only num_counts will be set to the length of the active_counts
 *    array.
 * \param num_counts The number of elements in active_counts. When the function returns, num_counts is set
 *     to the number of elements in active_counts. Must not be null.
 * \see sc_symbology_settings_set_active_symbol_counts
 *
 * \since 4.6.0
 * \memberof ScSymbologySettings
 */
SC_EXPORT void
sc_symbology_settings_get_active_symbol_counts(ScSymbologySettings * settings, uint16_t **active_counts,
                                               uint16_t *num_counts);

/** @}*/

#if defined(__cplusplus)
}
#endif


#endif // SC_SYMBOLOGY_SETTINGS_H_


