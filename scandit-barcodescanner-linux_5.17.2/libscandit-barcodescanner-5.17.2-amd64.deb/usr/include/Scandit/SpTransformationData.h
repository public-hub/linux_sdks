//------------------------------------------------------------------------------------------------//
//                        This file is part of the Scandit Parsing Library                        //
//                                                                                                //
//                   Copyright (c) 2016-2017 Scandit AG. All rights reserved                      //
//------------------------------------------------------------------------------------------------//

#ifndef SCANDIT_PARSER_TRANSFORMATION_DATA_H
#define SCANDIT_PARSER_TRANSFORMATION_DATA_H

#include <Scandit/Parser/SpCommon.h>

SP_BEGIN_EXTERN_C

typedef struct SpOpaqueTransformationData SpTransformationData;

/**
 * \brief Creates new transformation data that can be used as input to a transformation. The raw
 * data will be the same as the string data.
 *
 * \param type The type of the of data.
 * \param str The string value of the data.
 * \param str_length The length of the string value.
 */
SP_EXPORT SpTransformationData *
sp_transformation_data_new_no_raw(const char *type, const char *str, size_t str_length);

/**
 * \brief Creates new transformation data that can be used as input to a transformation.
 *
 * \param type The type of the of data.
 * \param str The string value of the data.
 * \param str_length The length of the string value.
 * \param raw The byte array value of the data.
 * \param raw_length The length of the byte array value.
 */
SP_EXPORT SpTransformationData *
sp_transformation_data_new(const char *type, const char *str, size_t str_length,
                           const unsigned char *raw, size_t raw_length);

/**
 * \brief Free the transformation data and any resource associated with it.
 *
 * \param data The transformation data. May be null.
 */
SP_EXPORT void sp_transformation_data_free(SpTransformationData *data);

/**
 * \brief Returns true when data contains valid content, false if an error
 * 		occurred during transformation.
 *
 * \param result The transformation data. Must not be NULL.
 */
SP_EXPORT SpBool sp_transformation_data_is_ok(const SpTransformationData *data);

/**
 * \brief Returns the error message of the transformation data.
 *
 * In case there were no errors, a NULL string is returned.
 *
 * \param data The transformation data. Must not be NULL.
 * \returns the error message. The life-time of the string is not bound to the
 * 		life-time of the of the transformation data. The user has to free the SpData
 * 		structure using sp_data_free.
 */
SP_EXPORT SpData sp_transformation_data_get_error_message(const SpTransformationData *data);

/**
 * \brief Returns the type of the transformation data.
 *
 * \param data The transformation data. Must not be NULL.
 * \returns the string value. The life-time of the string is not bound to the
 * 		life-time of the of the transformation data. The user has to free the SpData
 * 		structure using sp_data_free.
 */
SP_EXPORT SpData sp_transformation_data_get_type(const SpTransformationData *data);

/**
 * \brief Returns the string value of the transformation data.
 *
 * \param data The transformation data. Must not be NULL.
 * \returns the string value. The life-time of the string is not bound to the
 * 		life-time of the of the transformation data. The user has to free the SpData
 * 		structure using sp_data_free.
 */
SP_EXPORT SpData sp_transformation_data_get_string_value(const SpTransformationData *data);

/**
 * \brief Returns the byte array value of the transformation data.
 *
 * \param data The transformation data. Must not be NULL.
 * \returns the byte array value. The life-time of the string is not bound to the
 * 		life-time of the of the transformation data. The user has to free the SpData
 * 		structure using sp_data_free.
 */
SP_EXPORT SpData sp_transformation_data_get_byte_value(const SpTransformationData *data);


SP_END_EXTERN_C

#endif // SCANDIT_PARSER_TRANSFORMATION_DATA_H
